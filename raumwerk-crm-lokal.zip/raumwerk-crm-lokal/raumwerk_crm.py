#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
raumwerk CRM – lokale Version
=============================

Starten:   python3 raumwerk_crm.py        (Windows: py raumwerk_crm.py)
Beenden:   dieses Fenster schließen oder Strg + C

Das Skript braucht nur Python 3.7 oder neuer, keine Zusatzpakete und kein
Internet (außer für die Schriften). Es startet einen kleinen Server, der nur
auf diesem Computer erreichbar ist, und öffnet das CRM im Browser.

Alle Leads liegen im Ordner „raumwerk-daten“ neben diesem Skript:
  leads.json              die aktuellen Daten
  sicherungen/            eine automatische Sicherung pro Tag (die letzten 60)

Optionen:
  --port 8765             anderen Port verwenden
  --daten PFAD            anderen Datenordner verwenden
  --kein-browser          Browser nicht automatisch öffnen
  --handy                 auch im eigenen WLAN erreichbar machen (für Handy/Tablet,
                          nur mit Zugangsschlüssel – siehe Einstellungen im CRM)
"""

import argparse
import hmac
import json
import os
import re
import secrets
import shutil
import socket
import sys
import tempfile
import threading
import time
import urllib.parse
import urllib.request
import webbrowser
from datetime import date, datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

APP_NAME = "raumwerk CRM"
VERSION = "2026-10-16c"
STANDARD_PORT = 8765
MAX_SICHERUNGEN = 60
MAX_GROESSE = 50 * 1024 * 1024  # 50 MB pro Speichervorgang

HTML = r'''<!DOCTYPE html>
<html lang="de">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
<meta name="robots" content="noindex, nofollow">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-title" content="raumwerk">
<meta name="theme-color" content="#F4F1EA">
<title>raumwerk · Leads</title>
<link rel="icon" href="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 64 64'%3E%3Crect width='64' height='64' rx='12' fill='%2323332A'/%3E%3Ctext x='32' y='45' font-family='Georgia,serif' font-style='italic' font-size='40' text-anchor='middle' fill='%23F4F1EA'%3Er%3C/text%3E%3C/svg%3E">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,400;0,500;0,600;1,400;1,500&family=DM+Sans:opsz,wght@9..40,400;9..40,500;9..40,600&display=swap" rel="stylesheet">
<!--RW_SERVER-->
<style>
:root{
  --bg:#F4F1EA;
  --bg-alt:#ECEBE3;
  --surface:#FBFAF6;
  --ink:#23332A;
  --ink-soft:#3A4A3F;
  --sage:#6E7A5E;
  --sage-soft:#A7AE96;
  --muted:#6B6F68;
  --faint:#9A9C94;
  --line:#DCD8CC;
  --line-sage:#C8CCBA;
  --accent-warm:#9A6B4F;
  --serif:"Cormorant Garamond", Georgia, "Times New Roman", serif;
  --sans:"DM Sans", system-ui, -apple-system, "Segoe UI", sans-serif;
  --radius:4px;
  --shadow:0 1px 0 rgba(35,51,42,.04), 0 1px 2px rgba(35,51,42,.05);
  --shadow-lift:0 18px 40px -12px rgba(35,51,42,.28), 0 2px 6px rgba(35,51,42,.10);
}
*{box-sizing:border-box}
html,body{height:100%}
body{
  margin:0;background:var(--bg);color:var(--ink);
  font-family:var(--sans);font-size:15px;line-height:1.55;
  -webkit-font-smoothing:antialiased;-webkit-text-size-adjust:100%;
  display:flex;flex-direction:column;overflow:hidden;
}
button,input,select,textarea{font:inherit;color:inherit}
button{cursor:pointer;background:none;border:0;padding:0}
a{color:inherit}
.label{font-size:11.5px;letter-spacing:.16em;text-transform:uppercase;color:var(--muted);font-weight:500}
.serif{font-family:var(--serif)}
.it{font-style:italic;color:var(--sage)}
svg.i{width:16px;height:16px;flex:none;stroke:currentColor;fill:none;stroke-width:1.5;stroke-linecap:round;stroke-linejoin:round}

/* ---------- Kopfzeile ---------- */
.top{
  display:flex;align-items:center;gap:28px;
  padding:18px max(24px, env(safe-area-inset-right)) 16px max(24px, env(safe-area-inset-left));
  border-bottom:1px solid var(--line);background:var(--bg);flex:none;
}
.brand{display:flex;align-items:baseline;gap:14px;white-space:nowrap}
.brand .word{font-family:var(--serif);font-size:30px;line-height:1;font-weight:500;letter-spacing:-.01em}
.brand .word i{color:var(--sage);font-weight:400}
.brand .label{transform:translateY(-3px)}
.stats{display:flex;gap:22px;color:var(--muted);font-size:13.5px;white-space:nowrap}
.stats b{color:var(--ink);font-weight:500;font-variant-numeric:tabular-nums}
.stats .due b{color:var(--accent-warm)}
.top .spacer{flex:1}
.search{
  display:flex;align-items:center;gap:8px;border-bottom:1px solid var(--line-sage);
  padding:6px 2px;min-width:200px;color:var(--muted);
}
.search input{border:0;background:transparent;outline:0;width:100%;color:var(--ink)}
.search input::placeholder{color:var(--faint)}
.btn{
  display:inline-flex;align-items:center;gap:8px;white-space:nowrap;
  padding:10px 18px;border-radius:999px;font-size:14px;font-weight:500;
  transition:background .15s, color .15s, border-color .15s;
}
.btn-primary{background:var(--ink);color:var(--bg)}
.btn-primary:hover{background:#1A2820}
.btn-line{border:1px solid var(--line-sage);color:var(--ink)}
.btn-line:hover{border-color:var(--ink)}
.btn-quiet{color:var(--muted);padding:10px 10px}
.btn-quiet:hover{color:var(--ink)}
.btn-sm{padding:7px 14px;font-size:13px}
.link-arrow{display:inline-flex;align-items:center;gap:8px;font-weight:500;color:var(--ink);font-size:14px}
.link-arrow:hover .arr{transform:translate(2px,-2px)}
.arr{transition:transform .15s}

/* ---------- Board ---------- */
.board{
  flex:1;min-height:0;display:flex;gap:18px;overflow-x:auto;overflow-y:hidden;
  padding:22px max(24px, env(safe-area-inset-right)) 18px max(24px, env(safe-area-inset-left));
  -webkit-overflow-scrolling:touch;scroll-snap-type:x proximity;scroll-padding:0 24px;
}
.col{
  flex:0 0 288px;display:flex;flex-direction:column;min-height:0;
  scroll-snap-align:start;
}
.col-head{padding:0 2px 12px;border-bottom:1px solid var(--line);margin-bottom:12px;display:flex;align-items:flex-end;justify-content:space-between;gap:10px}
.col-head h2{margin:6px 0 0;font-family:var(--serif);font-weight:500;font-size:24px;line-height:1.1;letter-spacing:-.005em}
.col-head h2 i{color:var(--sage);font-weight:400}
.col-count{font-family:var(--serif);font-size:24px;line-height:1.1;color:var(--faint);font-variant-numeric:lining-nums tabular-nums}
.col[data-stage="closed"] .col-head{border-bottom-color:var(--sage-soft)}
.col-list{
  flex:1;min-height:80px;overflow-y:auto;overflow-x:hidden;padding:2px 2px 40px;
  display:flex;flex-direction:column;gap:10px;-webkit-overflow-scrolling:touch;
  border-radius:var(--radius);transition:background .15s;
}
.col.is-target .col-list{background:rgba(110,122,94,.07)}
.col-empty{
  border:1px dashed var(--line-sage);border-radius:var(--radius);padding:22px 14px;
  text-align:center;color:var(--faint);font-size:13px;
}
.col.is-target .col-empty{display:none}

/* ---------- Karte ---------- */
.card{
  position:relative;background:var(--surface);border:1px solid var(--line);border-radius:var(--radius);
  padding:14px 14px 13px;box-shadow:var(--shadow);cursor:grab;
  -webkit-user-select:none;user-select:none;-webkit-touch-callout:none;touch-action:manipulation;
  transition:border-color .15s, box-shadow .15s;
}
.card:hover{border-color:var(--line-sage)}
.card-top{display:flex;justify-content:space-between;align-items:baseline;gap:10px}
.card-name{font-weight:500;font-size:15px;line-height:1.35;overflow-wrap:anywhere}
.card-age{font-size:12px;color:var(--faint);white-space:nowrap}
.card-firm{color:var(--muted);font-size:13.5px;margin-top:1px;overflow-wrap:anywhere}
.card-meta{display:flex;flex-wrap:wrap;gap:6px 14px;margin-top:9px;font-size:12.5px;color:var(--muted)}
.card-meta span{display:inline-flex;align-items:center;gap:6px}
.card-meta svg.i{width:13px;height:13px}
.card-note{
  margin:10px 0 0;padding-top:9px;border-top:1px solid var(--line);font-size:13px;color:var(--ink-soft);
  display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;
}
.badge{display:inline-flex;align-items:center;gap:6px;font-size:11.5px;letter-spacing:.06em;color:var(--muted)}
.badge::before{content:"";width:5px;height:5px;border-radius:50%;background:currentColor}
.badge.warm{color:var(--accent-warm)}
.card-badges{display:flex;flex-wrap:wrap;gap:4px 12px;margin-top:9px}
.warnbar{border:1px solid #E2C9B8;background:#F6E9E1;color:#5A3A28;border-radius:var(--radius);padding:10px 14px;font-size:13.5px}
.warnbar b{font-weight:600}
.card-mail{
  margin-top:12px;width:100%;display:flex;align-items:center;justify-content:space-between;
  padding:9px 12px;border-radius:999px;background:var(--ink);color:var(--bg);font-size:13px;font-weight:500;
}
.card-mail:hover{background:#1A2820}
.card-mail[disabled]{background:var(--bg-alt);color:var(--faint);cursor:default}
.card-sent{font-size:12px;color:var(--faint);margin-top:7px;text-align:center}
.card.is-placeholder{opacity:.35;border-style:dashed;box-shadow:none}
.ghost{
  position:fixed;z-index:200;pointer-events:none;margin:0;
  box-shadow:var(--shadow-lift);transform:rotate(1.2deg) scale(1.02);cursor:grabbing;
  border-color:var(--line-sage);
}
body.dragging, body.dragging *{cursor:grabbing!important}
.card.is-pressing{transform:scale(.985);transition:transform .2s}

/* ---------- Overlays ---------- */
.overlay{
  position:fixed;inset:0;z-index:100;background:rgba(35,51,42,.32);
  display:none;align-items:center;justify-content:center;padding:28px;
  -webkit-backdrop-filter:blur(2px);backdrop-filter:blur(2px);
}
.overlay.open{display:flex;animation:fade .18s ease-out}
@keyframes fade{from{opacity:0}to{opacity:1}}
.panel{
  background:var(--bg);border-radius:6px;width:100%;max-width:1100px;max-height:100%;
  display:flex;flex-direction:column;overflow:hidden;box-shadow:0 30px 80px -20px rgba(35,51,42,.45);
}
.panel-head{display:flex;align-items:center;justify-content:space-between;gap:16px;padding:18px 26px;border-bottom:1px solid var(--line)}
.close{width:38px;height:38px;border-radius:50%;display:grid;place-items:center;color:var(--muted);border:1px solid var(--line)}
.close:hover{color:var(--ink);border-color:var(--ink)}

/* Detail */
.detail{height:min(860px,100%)}
.detail-body{flex:1;min-height:0;display:grid;grid-template-columns:360px 1fr}
.detail-side > *{flex-shrink:0}
.detail-side{background:var(--bg-alt);padding:28px 28px 22px;overflow-y:auto;border-right:1px solid var(--line);display:flex;flex-direction:column}
.detail-name{font-family:var(--serif);font-size:38px;line-height:1.05;font-weight:500;margin:10px 0 2px;letter-spacing:-.01em;overflow-wrap:anywhere}
.detail-firm{font-family:var(--serif);font-style:italic;font-size:23px;line-height:1.2;color:var(--sage);min-height:4px;overflow-wrap:anywhere}
.stage-select{
  margin-top:20px;display:flex;align-items:center;gap:10px;border:1px solid var(--line-sage);border-radius:999px;
  padding:0 14px;background:var(--surface);
}
.stage-select select{flex:1;border:0;background:transparent;padding:10px 0;outline:0;font-weight:500;-webkit-appearance:none;appearance:none}
.fields{margin-top:22px;border-top:1px solid var(--line-sage)}
.field{display:grid;grid-template-columns:1fr auto;align-items:end;gap:8px;padding:10px 0 9px;border-bottom:1px solid var(--line-sage)}
.field .label{grid-column:1/-1;font-size:10.5px;margin-bottom:-4px}
.field input,.field select{
  width:100%;border:0;background:transparent;outline:0;padding:3px 0;font-size:15px;color:var(--ink);
  border-radius:0;-webkit-appearance:none;appearance:none;min-height:28px;
}
.field input::placeholder{color:var(--faint)}
.field input:focus{box-shadow:0 1px 0 var(--ink)}
.fact{width:34px;height:34px;border-radius:50%;display:grid;place-items:center;border:1px solid var(--line-sage);color:var(--ink);text-decoration:none;background:var(--surface)}
.fact:hover{border-color:var(--ink)}
.fact.off{opacity:.35;pointer-events:none}
.extra{border:1px solid var(--line);border-radius:var(--radius);background:var(--surface);padding:16px 20px 12px}
.extra-head{display:flex;justify-content:space-between;align-items:center;gap:12px}
.extra-head .add-field{margin:0}
.extra-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(210px,1fr));gap:0 26px;margin-top:4px}
.extra-grid .field{border-bottom-color:var(--line)}
.extra-empty{margin:8px 0 2px;color:var(--faint);font-size:13.5px}
.extra .field:last-child{border-bottom-color:var(--line)}
.field textarea{width:100%;border:0;background:transparent;outline:0;padding:3px 0;font-size:15px;color:var(--ink);resize:vertical;line-height:1.5;font-family:inherit}
.field textarea:focus{box-shadow:0 1px 0 var(--ink)}
.fact-sm{width:26px;height:26px;color:var(--faint);border-color:transparent;background:transparent;opacity:.6}
.fact-sm svg.i{width:13px;height:13px}
.field:hover .fact-sm,.fact-sm:focus{opacity:1}
.fact-sm:hover{color:var(--accent-warm);border-color:var(--line-sage)}
.add-field{margin-top:14px;color:var(--sage);font-size:13.5px;font-weight:500}
.add-field:hover{color:var(--ink)}
.side-foot{margin-top:auto;padding-top:22px;display:flex;justify-content:space-between;align-items:center;gap:10px;font-size:12.5px;color:var(--faint)}
.danger{color:var(--accent-warm);font-size:13px}
.danger:hover{text-decoration:underline}
.saved{transition:opacity .3s}

.detail-main{padding:28px 32px;overflow-y:auto;display:flex;flex-direction:column;gap:18px}
.main-title{font-family:var(--serif);font-weight:500;font-size:30px;line-height:1.1;margin:8px 0 0}
.quick{display:flex;flex-wrap:wrap;gap:10px}
.compose{border:1px solid var(--line-sage);border-radius:var(--radius);background:var(--surface)}
.compose textarea{
  width:100%;min-height:110px;border:0;background:transparent;resize:vertical;outline:0;
  padding:16px 18px;font-size:15px;line-height:1.6;display:block;
}
.compose textarea::placeholder{color:var(--faint)}
.compose-foot{display:flex;justify-content:space-between;align-items:center;padding:10px 12px 10px 18px;border-top:1px solid var(--line);font-size:12.5px;color:var(--faint)}
.timeline{list-style:none;margin:0;padding:0;border-top:1px solid var(--line)}
.tl{padding:16px 0;border-bottom:1px solid var(--line);display:grid;grid-template-columns:132px 1fr auto;gap:16px;align-items:start}
.tl-date{font-size:12.5px;color:var(--faint);line-height:1.5;padding-top:2px}
.tl-text{white-space:pre-wrap;overflow-wrap:anywhere}
.tl.sys .tl-text{color:var(--muted);font-size:13.5px}
.tl.sys .tl-text::before{content:"— ";color:var(--faint)}
.tl-del{color:var(--faint);opacity:0;transition:opacity .15s;width:26px;height:26px;display:grid;place-items:center;border-radius:50%}
.tl:hover .tl-del{opacity:1}
.tl-del:hover{color:var(--accent-warm)}
@media (hover:none){.tl-del{opacity:.6}.compose-foot > span{visibility:hidden}}
.tl-empty{padding:22px 0;color:var(--faint);font-size:14px}

/* Import / Einstellungen */
.sheet{max-width:980px;height:min(820px,100%)}
.sheet-body{flex:1;min-height:0;overflow-y:auto;padding:26px 28px}
.sheet-foot{display:flex;justify-content:space-between;align-items:center;gap:14px;padding:16px 26px;border-top:1px solid var(--line);flex-wrap:wrap}
.tabs{display:flex;gap:24px;border-bottom:1px solid var(--line);margin-bottom:22px}
.tab{padding:0 0 12px;margin-bottom:-1px;color:var(--muted);font-weight:500;border-bottom:1px solid transparent}
.tab.on{color:var(--ink);border-bottom-color:var(--ink)}
.h-serif{font-family:var(--serif);font-weight:500;font-size:34px;line-height:1.08;margin:6px 0 4px;letter-spacing:-.01em}
.lead-text{color:var(--muted);max-width:640px;margin:0 0 18px}
.paste{
  width:100%;min-height:170px;border:1px solid var(--line-sage);border-radius:var(--radius);background:var(--surface);
  padding:14px 16px;font-size:14px;line-height:1.6;outline:0;resize:vertical;
  font-family:ui-monospace,"SF Mono",Menlo,Consolas,monospace;
}
.paste:focus,.input:focus,.area:focus{border-color:var(--ink)}
.hint{font-size:13px;color:var(--faint);margin-top:8px}
.compose-sheet{max-width:860px}
.tpl-list{display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:10px;margin-top:14px}
.tpl{display:flex;flex-direction:column;gap:3px;text-align:left;border:1px solid var(--line-sage);border-radius:var(--radius);background:var(--surface);padding:12px 14px}
.tpl:hover{border-color:var(--ink-soft)}
.tpl.on{border-color:var(--ink);box-shadow:inset 0 0 0 1px var(--ink)}
.tpl b{font-weight:500}
.tpl small{color:var(--muted);font-size:12.5px;line-height:1.4;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden}
.move-check{display:flex;align-items:center;gap:8px;font-size:13.5px;color:var(--ink-soft);cursor:pointer}
.move-check input{accent-color:var(--ink);width:16px;height:16px}
.tpl-bar{display:flex;gap:10px;flex-wrap:wrap;align-items:end}
.tpl-bar .fl{flex:1;min-width:180px}
.phone-box{display:flex;gap:26px;align-items:flex-start;flex-wrap:wrap}
.qr{background:#fff;border:1px solid var(--line);border-radius:var(--radius);padding:10px;line-height:0}
.qr svg{width:190px;height:190px;display:block}
.phone-steps{flex:1;min-width:240px;margin:0;padding-left:20px;color:var(--ink-soft)}
.phone-steps li{margin-bottom:8px}
.phone-link{font-family:ui-monospace,Menlo,monospace;font-size:12.5px;word-break:break-all;color:var(--muted);margin-top:12px}
.file-row{display:flex;align-items:center;gap:14px;flex-wrap:wrap;margin-top:12px}
.preview{width:100%;border-collapse:collapse;margin-top:22px;font-size:13.5px}
.preview th{text-align:left;font-weight:500;font-size:10.5px;letter-spacing:.14em;text-transform:uppercase;color:var(--muted);padding:0 10px 10px 0;border-bottom:1px solid var(--line-sage)}
.preview td{padding:10px 10px 10px 0;border-bottom:1px solid var(--line);vertical-align:top;overflow-wrap:anywhere}
.preview tr.dup td{color:var(--faint)}
.preview input[type=checkbox]{accent-color:var(--ink);width:16px;height:16px}
.dup-tag{display:block;font-size:11px;color:var(--accent-warm);margin-top:2px}
.grid2{display:grid;grid-template-columns:1fr 1fr;gap:16px 22px}
.fl{display:flex;flex-direction:column;gap:6px}
.fl .label{font-size:10.5px}
.input,.area{
  width:100%;border:1px solid var(--line-sage);border-radius:var(--radius);background:var(--surface);
  padding:10px 12px;outline:0;font-size:15px;
}
.area{min-height:280px;resize:vertical;line-height:1.6}
select.input{-webkit-appearance:none;appearance:none}
.span2{grid-column:1/-1}
.section{padding:0 0 28px;margin:0 0 28px;border-bottom:1px solid var(--line)}
.section:last-child{border-bottom:0;margin-bottom:0}
.chips{display:flex;flex-wrap:wrap;gap:8px;margin-top:10px}
.chip{border:1px solid var(--line-sage);border-radius:999px;padding:4px 11px;font-size:12.5px;color:var(--ink-soft);background:var(--surface);font-family:ui-monospace,Menlo,monospace}
.chip:hover{border-color:var(--ink)}
.mail-preview{border:1px solid var(--line);border-radius:var(--radius);background:var(--surface);padding:18px 20px;white-space:pre-wrap;font-size:14px;color:var(--ink-soft)}
.mail-preview .subj{font-weight:600;color:var(--ink);display:block;margin-bottom:12px;padding-bottom:12px;border-bottom:1px solid var(--line)}
.radio-row{display:flex;flex-wrap:wrap;gap:10px}
.radio-row label{display:flex;align-items:center;gap:8px;border:1px solid var(--line-sage);border-radius:999px;padding:8px 14px;cursor:pointer;font-size:14px;background:var(--surface)}
.radio-row input{accent-color:var(--ink)}
.radio-row label:has(input:checked){border-color:var(--ink)}

/* Hinweis */
.toast{
  position:fixed;left:50%;bottom:calc(24px + env(safe-area-inset-bottom));transform:translate(-50%,20px);
  background:var(--ink);color:var(--bg);padding:11px 12px 11px 20px;border-radius:999px;font-size:14px;
  display:flex;align-items:center;gap:14px;opacity:0;pointer-events:none;transition:opacity .2s, transform .2s;z-index:300;
  max-width:calc(100% - 32px);
}
.toast.show{opacity:1;transform:translate(-50%,0);pointer-events:auto}
.toast button{color:var(--bg);text-decoration:underline;text-underline-offset:3px;padding:0 8px;font-size:14px}
.toast:not(.has-action){padding-right:20px}

.hidden{display:none!important}
.boot{margin:auto;max-width:520px;text-align:center;padding:40px 16px}
.boot-title{font-family:var(--serif);font-size:30px;line-height:1.15;margin:10px 0 8px}
.boot-text{color:var(--muted);margin:0}
.err-bar{position:fixed;left:16px;right:16px;top:12px;z-index:400;background:#F6E9E1;color:#5A3A28;border:1px solid #E2C9B8;border-radius:var(--radius);padding:10px 14px;font-size:13.5px;display:flex;gap:12px;align-items:flex-start}
.err-bar button{margin-left:auto;text-decoration:underline;font-size:13px;color:inherit}
@media (pointer:coarse){input,select,textarea{font-size:16px!important}}

@media (max-width:1180px){
  .stats{display:none}
}
@media (max-width:820px){
  .top{flex-wrap:wrap;gap:12px 16px;padding:14px 16px}
  .top .spacer{display:none}
  .search{order:5;flex:1 1 100%}
  .brand .label{display:none}
  .board{padding:16px;gap:14px;scroll-padding:0 16px}
  .col{flex-basis:82vw}
  .overlay{padding:0}
  .panel{border-radius:0;height:100%;max-height:none}
  .detail-body{grid-template-columns:1fr;overflow-y:auto}
  .detail-side,.detail-main{overflow:visible}
  .detail-side{border-right:0;border-bottom:1px solid var(--line)}
  .detail-main{padding:24px 20px}
  .tl{grid-template-columns:1fr auto}
  .tl-date{grid-column:1/-1;padding:0}
  .grid2{grid-template-columns:1fr}
  .sheet-body{padding:22px 16px}
  .panel-head,.sheet-foot{padding:14px 16px}
  .preview .opt{display:none}
}
</style>
</head>
<body>

<header class="top">
  <div class="brand">
    <span class="word">raum<i>werk</i></span>
    <span class="label">Leads</span>
  </div>
  <div class="stats" id="stats"></div>
  <div class="spacer"></div>
  <label class="search">
    <svg class="i" viewBox="0 0 24 24"><circle cx="11" cy="11" r="6.5"/><path d="M20 20l-4.2-4.2"/></svg>
    <input id="search" type="search" placeholder="Suchen – Name, Firma, Ort …" autocomplete="off">
  </label>
  <button type="button" class="btn btn-quiet" id="openSettings" title="Einstellungen">
    <svg class="i" viewBox="0 0 24 24"><path d="M4 7h10M18 7h2M4 17h4M12 17h8"/><circle cx="16" cy="7" r="2"/><circle cx="10" cy="17" r="2"/></svg>
    Einstellungen
  </button>
  <button type="button" class="btn btn-primary" id="openImport">
    <svg class="i" viewBox="0 0 24 24"><path d="M12 5v14M5 12h14"/></svg>
    Leads einfügen
  </button>
</header>

<main class="board" id="board">
  <div class="boot" id="boot">
    <span class="label">raumwerk / Leads</span>
    <p class="boot-title">Das Board wird geladen …</p>
    <p class="boot-text">Bleibt diese Meldung stehen, wird die Seite in einer Vorschau ohne JavaScript angezeigt. Bitte den Link direkt in Safari oder Chrome öffnen.</p>
  </div>
</main>

<!-- Lead-Detail -->
<div class="overlay" id="detailOverlay">
  <section class="panel detail" role="dialog" aria-modal="true" aria-label="Lead">
    <div class="detail-body">
      <aside class="detail-side">
        <div style="display:flex;justify-content:space-between;align-items:center;gap:12px">
          <span class="label" id="dSince"></span>
          <button type="button" class="close" data-close aria-label="Schließen"><svg class="i" viewBox="0 0 24 24"><path d="M6 6l12 12M18 6L6 18"/></svg></button>
        </div>
        <h1 class="detail-name" id="dName"></h1>
        <div class="detail-firm" id="dFirm"></div>

        <label class="stage-select">
          <span class="label" style="font-size:10.5px">Phase</span>
          <select id="dStage"></select>
          <svg class="i" viewBox="0 0 24 24"><path d="M7 10l5 5 5-5"/></svg>
        </label>

        <div class="fields" id="dFields"></div>

        <div class="side-foot">
          <button type="button" class="danger" id="dDelete">Lead löschen</button>
          <span class="saved" id="dSaved">Änderungen werden gespeichert</span>
        </div>
      </aside>

      <div class="detail-main">
        <div>
          <span class="label">Verlauf &amp; Notizen</span>
          <h2 class="main-title">Was ist passiert, <span class="it">was kommt als Nächstes.</span></h2>
        </div>
        <div class="warnbar hidden" id="dWarn"></div>
        <section class="extra" id="dExtra"></section>
        <div class="quick" id="dQuick"></div>
        <div class="compose">
          <textarea id="dNote" placeholder="Notiz schreiben – z. B. „Rückruf Donnerstag, interessiert an Roomtour für Neubauprojekt.“"></textarea>
          <div class="compose-foot">
            <span>⌘ / Strg + Enter zum Speichern</span>
            <button type="button" class="btn btn-primary btn-sm" id="dAddNote">Notiz speichern</button>
          </div>
        </div>
        <ul class="timeline" id="dTimeline"></ul>
      </div>
    </div>
  </section>
</div>

<!-- E-Mail schreiben -->
<div class="overlay" id="composeOverlay">
  <section class="panel sheet compose-sheet" role="dialog" aria-modal="true" aria-label="E-Mail schreiben">
    <div class="panel-head">
      <span class="label" id="cTo">E-Mail schreiben</span>
      <button type="button" class="close" data-close aria-label="Schließen"><svg class="i" viewBox="0 0 24 24"><path d="M6 6l12 12M18 6L6 18"/></svg></button>
    </div>
    <div class="sheet-body">
      <h2 class="h-serif">Welche Nachricht <span class="it">soll es sein?</span></h2>
      <div class="tpl-list" id="cList"></div>
      <div class="grid2" id="cInputs" style="margin-top:18px"></div>
      <div style="margin-top:18px">
        <span class="label">Vorschau</span>
        <div class="mail-preview" id="cPreview" style="margin-top:8px"></div>
      </div>
    </div>
    <div class="sheet-foot">
      <label class="move-check" id="cMoveWrap"><input type="checkbox" id="cMove" checked> <span id="cMoveText"></span></label>
      <button type="button" class="btn btn-primary" id="cGo">In Gmail öffnen <svg class="i arr" viewBox="0 0 24 24"><path d="M7 17L17 7M9 7h8v8"/></svg></button>
    </div>
  </section>
</div>

<!-- Leads einfügen -->
<div class="overlay" id="importOverlay">
  <section class="panel sheet" role="dialog" aria-modal="true" aria-label="Leads einfügen">
    <div class="panel-head">
      <span class="label">Leads einfügen</span>
      <button type="button" class="close" data-close aria-label="Schließen"><svg class="i" viewBox="0 0 24 24"><path d="M6 6l12 12M18 6L6 18"/></svg></button>
    </div>
    <div class="sheet-body">
      <div class="tabs">
        <button type="button" class="tab on" data-tab="paste">Liste einfügen</button>
        <button type="button" class="tab" data-tab="single">Einzeln anlegen</button>
      </div>

      <div data-pane="paste">
        <h2 class="h-serif">Neue Kontakte. <span class="it">Direkt übernehmen.</span></h2>
        <p class="lead-text">Einfach hineinkopieren – aus Google Sheets, Excel, einer E-Mail oder WhatsApp. Eine Zeile pro Lead, oder Blöcke wie „Name: …“, „Telefon: …“ mit Leerzeile dazwischen. Name, Firma, Telefon und E-Mail werden automatisch erkannt.</p>
        <textarea class="paste" id="pasteArea" placeholder="Max Muster	Muster Immobilien GmbH	+49 171 2345678	max@muster-immobilien.de	München
Anna Beispiel; Beispiel &amp; Partner; 0151 9876543; a.beispiel@beispiel.de

Name: Jonas Weber
Firma: Weber Wohnbau
Telefon: 089 123456
E-Mail: weber@wohnbau.de"></textarea>
        <div class="file-row">
          <label class="btn btn-line btn-sm" for="leadFile" style="cursor:pointer">
            <svg class="i" viewBox="0 0 24 24"><path d="M12 15V4M7.5 8.5L12 4l4.5 4.5M5 15v4h14v-4"/></svg>
            Datei wählen
          </label>
          <span class="hint" id="leadFileHint" style="margin:0">Excel (.xlsx), Word (.docx), CSV oder Text – der Inhalt erscheint oben zur Kontrolle.</span>
          <input type="file" id="leadFile" accept=".xlsx,.docx,.csv,.tsv,.txt,text/csv,text/plain,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,application/vnd.openxmlformats-officedocument.wordprocessingml.document" style="position:absolute;width:1px;height:1px;opacity:0;pointer-events:none">
        </div>
        <div class="grid2" style="margin-top:16px">
          <label class="fl"><span class="label">Quelle (optional)</span><input class="input" id="pasteSource" placeholder="z. B. Liste Oktober"></label>
        </div>
        <div id="previewWrap"></div>
      </div>

      <div data-pane="single" class="hidden">
        <h2 class="h-serif">Ein Lead. <span class="it">Mit allen Angaben.</span></h2>
        <p class="lead-text">Pflicht ist nur der Name oder die Firma. Alles Weitere lässt sich später im Lead ergänzen.</p>
        <div class="grid2" id="singleForm">
          <label class="fl"><span class="label">Anrede</span>
            <select class="input" name="anrede"><option value="">–</option><option>Herr</option><option>Frau</option></select></label>
          <label class="fl"><span class="label">Name</span><input class="input" name="name" placeholder="Vor- und Nachname"></label>
          <label class="fl"><span class="label">Firma</span><input class="input" name="firma"></label>
          <label class="fl"><span class="label">Ort</span><input class="input" name="ort"></label>
          <label class="fl"><span class="label">Telefon</span><input class="input" name="telefon" type="tel"></label>
          <label class="fl"><span class="label">E-Mail</span><input class="input" name="email" type="email" autocapitalize="off"></label>
          <label class="fl"><span class="label">Website</span><input class="input" name="website" autocapitalize="off"></label>
          <label class="fl"><span class="label">Quelle</span><input class="input" name="quelle"></label>
          <label class="fl span2"><span class="label">Erste Notiz (optional)</span><textarea class="input" name="notiz" rows="3" style="resize:vertical"></textarea></label>
        </div>
      </div>
    </div>
    <div class="sheet-foot">
      <span class="hint" id="importHint" style="margin:0">Neue Leads landen in „Neuer Lead“.</span>
      <button type="button" class="btn btn-primary" id="importGo" disabled>Leads übernehmen</button>
    </div>
  </section>
</div>

<!-- Einstellungen -->
<div class="overlay" id="settingsOverlay">
  <section class="panel sheet" role="dialog" aria-modal="true" aria-label="Einstellungen">
    <div class="panel-head">
      <span class="label">Einstellungen</span>
      <button type="button" class="close" data-close aria-label="Schließen"><svg class="i" viewBox="0 0 24 24"><path d="M6 6l12 12M18 6L6 18"/></svg></button>
    </div>
    <div class="sheet-body">
      <div class="section">
        <span class="label">01 / E-Mail-Vorlagen</span>
        <h2 class="h-serif">Jede Nachricht. <span class="it">Persönlich vorbereitet.</span></h2>
        <p class="lead-text">Beim Klick auf „E-Mail schreiben“ wählen Sie eine dieser Vorlagen. Sie öffnet sich fertig ausgefüllt in Gmail – vor dem Senden kann alles noch angepasst werden.</p>
        <div class="tpl-bar">
          <label class="fl"><span class="label">Vorlage</span><select class="input" id="sTplSel"></select></label>
          <button type="button" class="btn btn-line btn-sm" id="sTplAdd">+ Neue Vorlage</button>
          <button type="button" class="btn btn-line btn-sm" id="sTplDel">Vorlage löschen</button>
        </div>
        <div class="grid2" style="margin-top:16px">
          <label class="fl"><span class="label">Name der Vorlage</span><input class="input" id="sTplName"></label>
          <label class="fl"><span class="label">Danach verschieben nach</span><select class="input" id="sTplStage"></select></label>
          <label class="fl span2"><span class="label">Betreff</span><input class="input" id="sSubject"></label>
          <label class="fl span2"><span class="label">Text</span><textarea class="area" id="sBody"></textarea></label>
        </div>
        <div class="chips" id="sChips"></div>
        <p class="hint">Antippen fügt den Platzhalter an der Cursor-Position ein. <code>{{begruessung}}</code> wird zu „Guten Tag Herr Weber“, „Guten Tag Frau Weber“ oder „Guten Tag“. <code>{{datum}}</code>, <code>{{uhrzeit}}</code> und <code>{{link}}</code> fragt das CRM beim Schreiben ab.</p>
        <div style="margin-top:18px">
          <span class="label">Vorschau</span>
          <div class="mail-preview" id="sPreview" style="margin-top:8px"></div>
        </div>
        <div style="margin-top:14px;display:flex;gap:10px;flex-wrap:wrap">
          <button type="button" class="btn btn-line btn-sm" id="sResetTpl">Diese Vorlage zurücksetzen</button>
        </div>
      </div>

      <div class="section">
        <span class="label">02 / Gmail</span>
        <h2 class="h-serif">Wo soll die Mail <span class="it">aufgehen?</span></h2>
        <p class="lead-text">Auf iPad und iPhone öffnet „Automatisch“ die Gmail-App, auf Android-Handys die Mail-App, am Computer Gmail im Browser. Falls auf dem iPad nichts passiert, ist die Gmail-App nicht installiert – dann „Gmail im Browser“ wählen.</p>
        <div class="radio-row" id="sMode">
          <label><input type="radio" name="mode" value="auto"> Automatisch</label>
          <label><input type="radio" name="mode" value="app"> Gmail-App</label>
          <label><input type="radio" name="mode" value="web"> Gmail im Browser</label>
          <label><input type="radio" name="mode" value="mailto"> Standard-Mailprogramm</label>
        </div>
        <div class="grid2" style="margin-top:18px">
          <label class="fl"><span class="label">Ihr Name (für {{absender}})</span><input class="input" id="sSender" placeholder="Vor- und Nachname"></label>
          <label class="fl"><span class="label">Ihre Telefonnummer (für {{absender_telefon}})</span><input class="input" id="sSenderPhone" type="tel" placeholder="z. B. +49 171 1234567"></label>
          <label class="fl"><span class="label">Link zum Beispielvideo (für {{video}})</span><input class="input" id="sVideo" type="url" placeholder="YouTube-, Vimeo- oder Drive-Link" autocapitalize="off"></label>
          <label class="fl"><span class="label">Gmail-Konto im Browser</span>
            <select class="input" id="sAccount">
              <option value="0">Erstes angemeldetes Konto</option>
              <option value="1">Zweites Konto</option>
              <option value="2">Drittes Konto</option>
            </select></label>
        </div>
      </div>

      <div class="section">
        <span class="label">03 / Daten</span>
        <h2 class="h-serif">Ihre Leads. <span class="it">Sicher aufbewahrt.</span></h2>
        <p class="lead-text" id="sDataText">Alle Daten liegen nur in diesem Browser auf diesem Gerät – ohne Server, ohne Kosten. Laden Sie regelmäßig eine Sicherung herunter. Damit lassen sich die Leads auch auf ein anderes Gerät übertragen.</p>
        <div style="display:flex;gap:10px;flex-wrap:wrap">
          <button type="button" class="btn btn-primary btn-sm" id="sExport">Sicherung herunterladen</button>
          <label class="btn btn-line btn-sm" for="sImportFile" style="cursor:pointer">Sicherung einspielen</label>
          <button type="button" class="btn btn-line btn-sm" id="sCsv">Als Tabelle (CSV)</button>
          <input type="file" id="sImportFile" accept=".json,application/json" style="position:absolute;width:1px;height:1px;opacity:0;pointer-events:none">
        </div>
        <p class="hint" id="sLastBackup"></p>
        <p class="hint" id="sVersion"></p>
        <div style="margin-top:22px">
          <button type="button" class="danger" id="sWipe">Alle Leads löschen</button>
        </div>
      </div>

      <div class="section hidden" id="sPhone">
        <span class="label">04 / Handy</span>
        <h2 class="h-serif">Ihr CRM. <span class="it">Auch unterwegs im Haus.</span></h2>
        <div id="sPhoneBody"></div>
      </div>
    </div>
  </section>
</div>

<div class="toast" id="toast"><span id="toastText"></span><button type="button" id="toastAction" class="hidden"></button></div>

<script>
/* QR-Code-Erzeugung für den Handy-Zugang: qrcode-generator 1.4.4, MIT-Lizenz */
//---------------------------------------------------------------------
//
// QR Code Generator for JavaScript
//
// Copyright (c) 2009 Kazuhiko Arase
//
// URL: http://www.d-project.com/
//
// Licensed under the MIT license:
//  http://www.opensource.org/licenses/mit-license.php
//
// The word 'QR Code' is registered trademark of
// DENSO WAVE INCORPORATED
//  http://www.denso-wave.com/qrcode/faqpatent-e.html
//
//---------------------------------------------------------------------

var qrcode = function() {

  //---------------------------------------------------------------------
  // qrcode
  //---------------------------------------------------------------------

  /**
   * qrcode
   * @param typeNumber 1 to 40
   * @param errorCorrectionLevel 'L','M','Q','H'
   */
  var qrcode = function(typeNumber, errorCorrectionLevel) {

    var PAD0 = 0xEC;
    var PAD1 = 0x11;

    var _typeNumber = typeNumber;
    var _errorCorrectionLevel = QRErrorCorrectionLevel[errorCorrectionLevel];
    var _modules = null;
    var _moduleCount = 0;
    var _dataCache = null;
    var _dataList = [];

    var _this = {};

    var makeImpl = function(test, maskPattern) {

      _moduleCount = _typeNumber * 4 + 17;
      _modules = function(moduleCount) {
        var modules = new Array(moduleCount);
        for (var row = 0; row < moduleCount; row += 1) {
          modules[row] = new Array(moduleCount);
          for (var col = 0; col < moduleCount; col += 1) {
            modules[row][col] = null;
          }
        }
        return modules;
      }(_moduleCount);

      setupPositionProbePattern(0, 0);
      setupPositionProbePattern(_moduleCount - 7, 0);
      setupPositionProbePattern(0, _moduleCount - 7);
      setupPositionAdjustPattern();
      setupTimingPattern();
      setupTypeInfo(test, maskPattern);

      if (_typeNumber >= 7) {
        setupTypeNumber(test);
      }

      if (_dataCache == null) {
        _dataCache = createData(_typeNumber, _errorCorrectionLevel, _dataList);
      }

      mapData(_dataCache, maskPattern);
    };

    var setupPositionProbePattern = function(row, col) {

      for (var r = -1; r <= 7; r += 1) {

        if (row + r <= -1 || _moduleCount <= row + r) continue;

        for (var c = -1; c <= 7; c += 1) {

          if (col + c <= -1 || _moduleCount <= col + c) continue;

          if ( (0 <= r && r <= 6 && (c == 0 || c == 6) )
              || (0 <= c && c <= 6 && (r == 0 || r == 6) )
              || (2 <= r && r <= 4 && 2 <= c && c <= 4) ) {
            _modules[row + r][col + c] = true;
          } else {
            _modules[row + r][col + c] = false;
          }
        }
      }
    };

    var getBestMaskPattern = function() {

      var minLostPoint = 0;
      var pattern = 0;

      for (var i = 0; i < 8; i += 1) {

        makeImpl(true, i);

        var lostPoint = QRUtil.getLostPoint(_this);

        if (i == 0 || minLostPoint > lostPoint) {
          minLostPoint = lostPoint;
          pattern = i;
        }
      }

      return pattern;
    };

    var setupTimingPattern = function() {

      for (var r = 8; r < _moduleCount - 8; r += 1) {
        if (_modules[r][6] != null) {
          continue;
        }
        _modules[r][6] = (r % 2 == 0);
      }

      for (var c = 8; c < _moduleCount - 8; c += 1) {
        if (_modules[6][c] != null) {
          continue;
        }
        _modules[6][c] = (c % 2 == 0);
      }
    };

    var setupPositionAdjustPattern = function() {

      var pos = QRUtil.getPatternPosition(_typeNumber);

      for (var i = 0; i < pos.length; i += 1) {

        for (var j = 0; j < pos.length; j += 1) {

          var row = pos[i];
          var col = pos[j];

          if (_modules[row][col] != null) {
            continue;
          }

          for (var r = -2; r <= 2; r += 1) {

            for (var c = -2; c <= 2; c += 1) {

              if (r == -2 || r == 2 || c == -2 || c == 2
                  || (r == 0 && c == 0) ) {
                _modules[row + r][col + c] = true;
              } else {
                _modules[row + r][col + c] = false;
              }
            }
          }
        }
      }
    };

    var setupTypeNumber = function(test) {

      var bits = QRUtil.getBCHTypeNumber(_typeNumber);

      for (var i = 0; i < 18; i += 1) {
        var mod = (!test && ( (bits >> i) & 1) == 1);
        _modules[Math.floor(i / 3)][i % 3 + _moduleCount - 8 - 3] = mod;
      }

      for (var i = 0; i < 18; i += 1) {
        var mod = (!test && ( (bits >> i) & 1) == 1);
        _modules[i % 3 + _moduleCount - 8 - 3][Math.floor(i / 3)] = mod;
      }
    };

    var setupTypeInfo = function(test, maskPattern) {

      var data = (_errorCorrectionLevel << 3) | maskPattern;
      var bits = QRUtil.getBCHTypeInfo(data);

      // vertical
      for (var i = 0; i < 15; i += 1) {

        var mod = (!test && ( (bits >> i) & 1) == 1);

        if (i < 6) {
          _modules[i][8] = mod;
        } else if (i < 8) {
          _modules[i + 1][8] = mod;
        } else {
          _modules[_moduleCount - 15 + i][8] = mod;
        }
      }

      // horizontal
      for (var i = 0; i < 15; i += 1) {

        var mod = (!test && ( (bits >> i) & 1) == 1);

        if (i < 8) {
          _modules[8][_moduleCount - i - 1] = mod;
        } else if (i < 9) {
          _modules[8][15 - i - 1 + 1] = mod;
        } else {
          _modules[8][15 - i - 1] = mod;
        }
      }

      // fixed module
      _modules[_moduleCount - 8][8] = (!test);
    };

    var mapData = function(data, maskPattern) {

      var inc = -1;
      var row = _moduleCount - 1;
      var bitIndex = 7;
      var byteIndex = 0;
      var maskFunc = QRUtil.getMaskFunction(maskPattern);

      for (var col = _moduleCount - 1; col > 0; col -= 2) {

        if (col == 6) col -= 1;

        while (true) {

          for (var c = 0; c < 2; c += 1) {

            if (_modules[row][col - c] == null) {

              var dark = false;

              if (byteIndex < data.length) {
                dark = ( ( (data[byteIndex] >>> bitIndex) & 1) == 1);
              }

              var mask = maskFunc(row, col - c);

              if (mask) {
                dark = !dark;
              }

              _modules[row][col - c] = dark;
              bitIndex -= 1;

              if (bitIndex == -1) {
                byteIndex += 1;
                bitIndex = 7;
              }
            }
          }

          row += inc;

          if (row < 0 || _moduleCount <= row) {
            row -= inc;
            inc = -inc;
            break;
          }
        }
      }
    };

    var createBytes = function(buffer, rsBlocks) {

      var offset = 0;

      var maxDcCount = 0;
      var maxEcCount = 0;

      var dcdata = new Array(rsBlocks.length);
      var ecdata = new Array(rsBlocks.length);

      for (var r = 0; r < rsBlocks.length; r += 1) {

        var dcCount = rsBlocks[r].dataCount;
        var ecCount = rsBlocks[r].totalCount - dcCount;

        maxDcCount = Math.max(maxDcCount, dcCount);
        maxEcCount = Math.max(maxEcCount, ecCount);

        dcdata[r] = new Array(dcCount);

        for (var i = 0; i < dcdata[r].length; i += 1) {
          dcdata[r][i] = 0xff & buffer.getBuffer()[i + offset];
        }
        offset += dcCount;

        var rsPoly = QRUtil.getErrorCorrectPolynomial(ecCount);
        var rawPoly = qrPolynomial(dcdata[r], rsPoly.getLength() - 1);

        var modPoly = rawPoly.mod(rsPoly);
        ecdata[r] = new Array(rsPoly.getLength() - 1);
        for (var i = 0; i < ecdata[r].length; i += 1) {
          var modIndex = i + modPoly.getLength() - ecdata[r].length;
          ecdata[r][i] = (modIndex >= 0)? modPoly.getAt(modIndex) : 0;
        }
      }

      var totalCodeCount = 0;
      for (var i = 0; i < rsBlocks.length; i += 1) {
        totalCodeCount += rsBlocks[i].totalCount;
      }

      var data = new Array(totalCodeCount);
      var index = 0;

      for (var i = 0; i < maxDcCount; i += 1) {
        for (var r = 0; r < rsBlocks.length; r += 1) {
          if (i < dcdata[r].length) {
            data[index] = dcdata[r][i];
            index += 1;
          }
        }
      }

      for (var i = 0; i < maxEcCount; i += 1) {
        for (var r = 0; r < rsBlocks.length; r += 1) {
          if (i < ecdata[r].length) {
            data[index] = ecdata[r][i];
            index += 1;
          }
        }
      }

      return data;
    };

    var createData = function(typeNumber, errorCorrectionLevel, dataList) {

      var rsBlocks = QRRSBlock.getRSBlocks(typeNumber, errorCorrectionLevel);

      var buffer = qrBitBuffer();

      for (var i = 0; i < dataList.length; i += 1) {
        var data = dataList[i];
        buffer.put(data.getMode(), 4);
        buffer.put(data.getLength(), QRUtil.getLengthInBits(data.getMode(), typeNumber) );
        data.write(buffer);
      }

      // calc num max data.
      var totalDataCount = 0;
      for (var i = 0; i < rsBlocks.length; i += 1) {
        totalDataCount += rsBlocks[i].dataCount;
      }

      if (buffer.getLengthInBits() > totalDataCount * 8) {
        throw 'code length overflow. ('
          + buffer.getLengthInBits()
          + '>'
          + totalDataCount * 8
          + ')';
      }

      // end code
      if (buffer.getLengthInBits() + 4 <= totalDataCount * 8) {
        buffer.put(0, 4);
      }

      // padding
      while (buffer.getLengthInBits() % 8 != 0) {
        buffer.putBit(false);
      }

      // padding
      while (true) {

        if (buffer.getLengthInBits() >= totalDataCount * 8) {
          break;
        }
        buffer.put(PAD0, 8);

        if (buffer.getLengthInBits() >= totalDataCount * 8) {
          break;
        }
        buffer.put(PAD1, 8);
      }

      return createBytes(buffer, rsBlocks);
    };

    _this.addData = function(data, mode) {

      mode = mode || 'Byte';

      var newData = null;

      switch(mode) {
      case 'Numeric' :
        newData = qrNumber(data);
        break;
      case 'Alphanumeric' :
        newData = qrAlphaNum(data);
        break;
      case 'Byte' :
        newData = qr8BitByte(data);
        break;
      case 'Kanji' :
        newData = qrKanji(data);
        break;
      default :
        throw 'mode:' + mode;
      }

      _dataList.push(newData);
      _dataCache = null;
    };

    _this.isDark = function(row, col) {
      if (row < 0 || _moduleCount <= row || col < 0 || _moduleCount <= col) {
        throw row + ',' + col;
      }
      return _modules[row][col];
    };

    _this.getModuleCount = function() {
      return _moduleCount;
    };

    _this.make = function() {
      if (_typeNumber < 1) {
        var typeNumber = 1;

        for (; typeNumber < 40; typeNumber++) {
          var rsBlocks = QRRSBlock.getRSBlocks(typeNumber, _errorCorrectionLevel);
          var buffer = qrBitBuffer();

          for (var i = 0; i < _dataList.length; i++) {
            var data = _dataList[i];
            buffer.put(data.getMode(), 4);
            buffer.put(data.getLength(), QRUtil.getLengthInBits(data.getMode(), typeNumber) );
            data.write(buffer);
          }

          var totalDataCount = 0;
          for (var i = 0; i < rsBlocks.length; i++) {
            totalDataCount += rsBlocks[i].dataCount;
          }

          if (buffer.getLengthInBits() <= totalDataCount * 8) {
            break;
          }
        }

        _typeNumber = typeNumber;
      }

      makeImpl(false, getBestMaskPattern() );
    };

    _this.createTableTag = function(cellSize, margin) {

      cellSize = cellSize || 2;
      margin = (typeof margin == 'undefined')? cellSize * 4 : margin;

      var qrHtml = '';

      qrHtml += '<table style="';
      qrHtml += ' border-width: 0px; border-style: none;';
      qrHtml += ' border-collapse: collapse;';
      qrHtml += ' padding: 0px; margin: ' + margin + 'px;';
      qrHtml += '">';
      qrHtml += '<tbody>';

      for (var r = 0; r < _this.getModuleCount(); r += 1) {

        qrHtml += '<tr>';

        for (var c = 0; c < _this.getModuleCount(); c += 1) {
          qrHtml += '<td style="';
          qrHtml += ' border-width: 0px; border-style: none;';
          qrHtml += ' border-collapse: collapse;';
          qrHtml += ' padding: 0px; margin: 0px;';
          qrHtml += ' width: ' + cellSize + 'px;';
          qrHtml += ' height: ' + cellSize + 'px;';
          qrHtml += ' background-color: ';
          qrHtml += _this.isDark(r, c)? '#000000' : '#ffffff';
          qrHtml += ';';
          qrHtml += '"/>';
        }

        qrHtml += '</tr>';
      }

      qrHtml += '</tbody>';
      qrHtml += '</table>';

      return qrHtml;
    };

    _this.createSvgTag = function(cellSize, margin, alt, title) {

      var opts = {};
      if (typeof arguments[0] == 'object') {
        // Called by options.
        opts = arguments[0];
        // overwrite cellSize and margin.
        cellSize = opts.cellSize;
        margin = opts.margin;
        alt = opts.alt;
        title = opts.title;
      }

      cellSize = cellSize || 2;
      margin = (typeof margin == 'undefined')? cellSize * 4 : margin;

      // Compose alt property surrogate
      alt = (typeof alt === 'string') ? {text: alt} : alt || {};
      alt.text = alt.text || null;
      alt.id = (alt.text) ? alt.id || 'qrcode-description' : null;

      // Compose title property surrogate
      title = (typeof title === 'string') ? {text: title} : title || {};
      title.text = title.text || null;
      title.id = (title.text) ? title.id || 'qrcode-title' : null;

      var size = _this.getModuleCount() * cellSize + margin * 2;
      var c, mc, r, mr, qrSvg='', rect;

      rect = 'l' + cellSize + ',0 0,' + cellSize +
        ' -' + cellSize + ',0 0,-' + cellSize + 'z ';

      qrSvg += '<svg version="1.1" xmlns="http://www.w3.org/2000/svg"';
      qrSvg += !opts.scalable ? ' width="' + size + 'px" height="' + size + 'px"' : '';
      qrSvg += ' viewBox="0 0 ' + size + ' ' + size + '" ';
      qrSvg += ' preserveAspectRatio="xMinYMin meet"';
      qrSvg += (title.text || alt.text) ? ' role="img" aria-labelledby="' +
          escapeXml([title.id, alt.id].join(' ').trim() ) + '"' : '';
      qrSvg += '>';
      qrSvg += (title.text) ? '<title id="' + escapeXml(title.id) + '">' +
          escapeXml(title.text) + '</title>' : '';
      qrSvg += (alt.text) ? '<description id="' + escapeXml(alt.id) + '">' +
          escapeXml(alt.text) + '</description>' : '';
      qrSvg += '<rect width="100%" height="100%" fill="white" cx="0" cy="0"/>';
      qrSvg += '<path d="';

      for (r = 0; r < _this.getModuleCount(); r += 1) {
        mr = r * cellSize + margin;
        for (c = 0; c < _this.getModuleCount(); c += 1) {
          if (_this.isDark(r, c) ) {
            mc = c*cellSize+margin;
            qrSvg += 'M' + mc + ',' + mr + rect;
          }
        }
      }

      qrSvg += '" stroke="transparent" fill="black"/>';
      qrSvg += '</svg>';

      return qrSvg;
    };

    _this.createDataURL = function(cellSize, margin) {

      cellSize = cellSize || 2;
      margin = (typeof margin == 'undefined')? cellSize * 4 : margin;

      var size = _this.getModuleCount() * cellSize + margin * 2;
      var min = margin;
      var max = size - margin;

      return createDataURL(size, size, function(x, y) {
        if (min <= x && x < max && min <= y && y < max) {
          var c = Math.floor( (x - min) / cellSize);
          var r = Math.floor( (y - min) / cellSize);
          return _this.isDark(r, c)? 0 : 1;
        } else {
          return 1;
        }
      } );
    };

    _this.createImgTag = function(cellSize, margin, alt) {

      cellSize = cellSize || 2;
      margin = (typeof margin == 'undefined')? cellSize * 4 : margin;

      var size = _this.getModuleCount() * cellSize + margin * 2;

      var img = '';
      img += '<img';
      img += '\u0020src="';
      img += _this.createDataURL(cellSize, margin);
      img += '"';
      img += '\u0020width="';
      img += size;
      img += '"';
      img += '\u0020height="';
      img += size;
      img += '"';
      if (alt) {
        img += '\u0020alt="';
        img += escapeXml(alt);
        img += '"';
      }
      img += '/>';

      return img;
    };

    var escapeXml = function(s) {
      var escaped = '';
      for (var i = 0; i < s.length; i += 1) {
        var c = s.charAt(i);
        switch(c) {
        case '<': escaped += '&lt;'; break;
        case '>': escaped += '&gt;'; break;
        case '&': escaped += '&amp;'; break;
        case '"': escaped += '&quot;'; break;
        default : escaped += c; break;
        }
      }
      return escaped;
    };

    var _createHalfASCII = function(margin) {
      var cellSize = 1;
      margin = (typeof margin == 'undefined')? cellSize * 2 : margin;

      var size = _this.getModuleCount() * cellSize + margin * 2;
      var min = margin;
      var max = size - margin;

      var y, x, r1, r2, p;

      var blocks = {
        '██': '█',
        '█ ': '▀',
        ' █': '▄',
        '  ': ' '
      };

      var blocksLastLineNoMargin = {
        '██': '▀',
        '█ ': '▀',
        ' █': ' ',
        '  ': ' '
      };

      var ascii = '';
      for (y = 0; y < size; y += 2) {
        r1 = Math.floor((y - min) / cellSize);
        r2 = Math.floor((y + 1 - min) / cellSize);
        for (x = 0; x < size; x += 1) {
          p = '█';

          if (min <= x && x < max && min <= y && y < max && _this.isDark(r1, Math.floor((x - min) / cellSize))) {
            p = ' ';
          }

          if (min <= x && x < max && min <= y+1 && y+1 < max && _this.isDark(r2, Math.floor((x - min) / cellSize))) {
            p += ' ';
          }
          else {
            p += '█';
          }

          // Output 2 characters per pixel, to create full square. 1 character per pixels gives only half width of square.
          ascii += (margin < 1 && y+1 >= max) ? blocksLastLineNoMargin[p] : blocks[p];
        }

        ascii += '\n';
      }

      if (size % 2 && margin > 0) {
        return ascii.substring(0, ascii.length - size - 1) + Array(size+1).join('▀');
      }

      return ascii.substring(0, ascii.length-1);
    };

    _this.createASCII = function(cellSize, margin) {
      cellSize = cellSize || 1;

      if (cellSize < 2) {
        return _createHalfASCII(margin);
      }

      cellSize -= 1;
      margin = (typeof margin == 'undefined')? cellSize * 2 : margin;

      var size = _this.getModuleCount() * cellSize + margin * 2;
      var min = margin;
      var max = size - margin;

      var y, x, r, p;

      var white = Array(cellSize+1).join('██');
      var black = Array(cellSize+1).join('  ');

      var ascii = '';
      var line = '';
      for (y = 0; y < size; y += 1) {
        r = Math.floor( (y - min) / cellSize);
        line = '';
        for (x = 0; x < size; x += 1) {
          p = 1;

          if (min <= x && x < max && min <= y && y < max && _this.isDark(r, Math.floor((x - min) / cellSize))) {
            p = 0;
          }

          // Output 2 characters per pixel, to create full square. 1 character per pixels gives only half width of square.
          line += p ? white : black;
        }

        for (r = 0; r < cellSize; r += 1) {
          ascii += line + '\n';
        }
      }

      return ascii.substring(0, ascii.length-1);
    };

    _this.renderTo2dContext = function(context, cellSize) {
      cellSize = cellSize || 2;
      var length = _this.getModuleCount();
      for (var row = 0; row < length; row++) {
        for (var col = 0; col < length; col++) {
          context.fillStyle = _this.isDark(row, col) ? 'black' : 'white';
          context.fillRect(row * cellSize, col * cellSize, cellSize, cellSize);
        }
      }
    }

    return _this;
  };

  //---------------------------------------------------------------------
  // qrcode.stringToBytes
  //---------------------------------------------------------------------

  qrcode.stringToBytesFuncs = {
    'default' : function(s) {
      var bytes = [];
      for (var i = 0; i < s.length; i += 1) {
        var c = s.charCodeAt(i);
        bytes.push(c & 0xff);
      }
      return bytes;
    }
  };

  qrcode.stringToBytes = qrcode.stringToBytesFuncs['default'];

  //---------------------------------------------------------------------
  // qrcode.createStringToBytes
  //---------------------------------------------------------------------

  /**
   * @param unicodeData base64 string of byte array.
   * [16bit Unicode],[16bit Bytes], ...
   * @param numChars
   */
  qrcode.createStringToBytes = function(unicodeData, numChars) {

    // create conversion map.

    var unicodeMap = function() {

      var bin = base64DecodeInputStream(unicodeData);
      var read = function() {
        var b = bin.read();
        if (b == -1) throw 'eof';
        return b;
      };

      var count = 0;
      var unicodeMap = {};
      while (true) {
        var b0 = bin.read();
        if (b0 == -1) break;
        var b1 = read();
        var b2 = read();
        var b3 = read();
        var k = String.fromCharCode( (b0 << 8) | b1);
        var v = (b2 << 8) | b3;
        unicodeMap[k] = v;
        count += 1;
      }
      if (count != numChars) {
        throw count + ' != ' + numChars;
      }

      return unicodeMap;
    }();

    var unknownChar = '?'.charCodeAt(0);

    return function(s) {
      var bytes = [];
      for (var i = 0; i < s.length; i += 1) {
        var c = s.charCodeAt(i);
        if (c < 128) {
          bytes.push(c);
        } else {
          var b = unicodeMap[s.charAt(i)];
          if (typeof b == 'number') {
            if ( (b & 0xff) == b) {
              // 1byte
              bytes.push(b);
            } else {
              // 2bytes
              bytes.push(b >>> 8);
              bytes.push(b & 0xff);
            }
          } else {
            bytes.push(unknownChar);
          }
        }
      }
      return bytes;
    };
  };

  //---------------------------------------------------------------------
  // QRMode
  //---------------------------------------------------------------------

  var QRMode = {
    MODE_NUMBER :    1 << 0,
    MODE_ALPHA_NUM : 1 << 1,
    MODE_8BIT_BYTE : 1 << 2,
    MODE_KANJI :     1 << 3
  };

  //---------------------------------------------------------------------
  // QRErrorCorrectionLevel
  //---------------------------------------------------------------------

  var QRErrorCorrectionLevel = {
    L : 1,
    M : 0,
    Q : 3,
    H : 2
  };

  //---------------------------------------------------------------------
  // QRMaskPattern
  //---------------------------------------------------------------------

  var QRMaskPattern = {
    PATTERN000 : 0,
    PATTERN001 : 1,
    PATTERN010 : 2,
    PATTERN011 : 3,
    PATTERN100 : 4,
    PATTERN101 : 5,
    PATTERN110 : 6,
    PATTERN111 : 7
  };

  //---------------------------------------------------------------------
  // QRUtil
  //---------------------------------------------------------------------

  var QRUtil = function() {

    var PATTERN_POSITION_TABLE = [
      [],
      [6, 18],
      [6, 22],
      [6, 26],
      [6, 30],
      [6, 34],
      [6, 22, 38],
      [6, 24, 42],
      [6, 26, 46],
      [6, 28, 50],
      [6, 30, 54],
      [6, 32, 58],
      [6, 34, 62],
      [6, 26, 46, 66],
      [6, 26, 48, 70],
      [6, 26, 50, 74],
      [6, 30, 54, 78],
      [6, 30, 56, 82],
      [6, 30, 58, 86],
      [6, 34, 62, 90],
      [6, 28, 50, 72, 94],
      [6, 26, 50, 74, 98],
      [6, 30, 54, 78, 102],
      [6, 28, 54, 80, 106],
      [6, 32, 58, 84, 110],
      [6, 30, 58, 86, 114],
      [6, 34, 62, 90, 118],
      [6, 26, 50, 74, 98, 122],
      [6, 30, 54, 78, 102, 126],
      [6, 26, 52, 78, 104, 130],
      [6, 30, 56, 82, 108, 134],
      [6, 34, 60, 86, 112, 138],
      [6, 30, 58, 86, 114, 142],
      [6, 34, 62, 90, 118, 146],
      [6, 30, 54, 78, 102, 126, 150],
      [6, 24, 50, 76, 102, 128, 154],
      [6, 28, 54, 80, 106, 132, 158],
      [6, 32, 58, 84, 110, 136, 162],
      [6, 26, 54, 82, 110, 138, 166],
      [6, 30, 58, 86, 114, 142, 170]
    ];
    var G15 = (1 << 10) | (1 << 8) | (1 << 5) | (1 << 4) | (1 << 2) | (1 << 1) | (1 << 0);
    var G18 = (1 << 12) | (1 << 11) | (1 << 10) | (1 << 9) | (1 << 8) | (1 << 5) | (1 << 2) | (1 << 0);
    var G15_MASK = (1 << 14) | (1 << 12) | (1 << 10) | (1 << 4) | (1 << 1);

    var _this = {};

    var getBCHDigit = function(data) {
      var digit = 0;
      while (data != 0) {
        digit += 1;
        data >>>= 1;
      }
      return digit;
    };

    _this.getBCHTypeInfo = function(data) {
      var d = data << 10;
      while (getBCHDigit(d) - getBCHDigit(G15) >= 0) {
        d ^= (G15 << (getBCHDigit(d) - getBCHDigit(G15) ) );
      }
      return ( (data << 10) | d) ^ G15_MASK;
    };

    _this.getBCHTypeNumber = function(data) {
      var d = data << 12;
      while (getBCHDigit(d) - getBCHDigit(G18) >= 0) {
        d ^= (G18 << (getBCHDigit(d) - getBCHDigit(G18) ) );
      }
      return (data << 12) | d;
    };

    _this.getPatternPosition = function(typeNumber) {
      return PATTERN_POSITION_TABLE[typeNumber - 1];
    };

    _this.getMaskFunction = function(maskPattern) {

      switch (maskPattern) {

      case QRMaskPattern.PATTERN000 :
        return function(i, j) { return (i + j) % 2 == 0; };
      case QRMaskPattern.PATTERN001 :
        return function(i, j) { return i % 2 == 0; };
      case QRMaskPattern.PATTERN010 :
        return function(i, j) { return j % 3 == 0; };
      case QRMaskPattern.PATTERN011 :
        return function(i, j) { return (i + j) % 3 == 0; };
      case QRMaskPattern.PATTERN100 :
        return function(i, j) { return (Math.floor(i / 2) + Math.floor(j / 3) ) % 2 == 0; };
      case QRMaskPattern.PATTERN101 :
        return function(i, j) { return (i * j) % 2 + (i * j) % 3 == 0; };
      case QRMaskPattern.PATTERN110 :
        return function(i, j) { return ( (i * j) % 2 + (i * j) % 3) % 2 == 0; };
      case QRMaskPattern.PATTERN111 :
        return function(i, j) { return ( (i * j) % 3 + (i + j) % 2) % 2 == 0; };

      default :
        throw 'bad maskPattern:' + maskPattern;
      }
    };

    _this.getErrorCorrectPolynomial = function(errorCorrectLength) {
      var a = qrPolynomial([1], 0);
      for (var i = 0; i < errorCorrectLength; i += 1) {
        a = a.multiply(qrPolynomial([1, QRMath.gexp(i)], 0) );
      }
      return a;
    };

    _this.getLengthInBits = function(mode, type) {

      if (1 <= type && type < 10) {

        // 1 - 9

        switch(mode) {
        case QRMode.MODE_NUMBER    : return 10;
        case QRMode.MODE_ALPHA_NUM : return 9;
        case QRMode.MODE_8BIT_BYTE : return 8;
        case QRMode.MODE_KANJI     : return 8;
        default :
          throw 'mode:' + mode;
        }

      } else if (type < 27) {

        // 10 - 26

        switch(mode) {
        case QRMode.MODE_NUMBER    : return 12;
        case QRMode.MODE_ALPHA_NUM : return 11;
        case QRMode.MODE_8BIT_BYTE : return 16;
        case QRMode.MODE_KANJI     : return 10;
        default :
          throw 'mode:' + mode;
        }

      } else if (type < 41) {

        // 27 - 40

        switch(mode) {
        case QRMode.MODE_NUMBER    : return 14;
        case QRMode.MODE_ALPHA_NUM : return 13;
        case QRMode.MODE_8BIT_BYTE : return 16;
        case QRMode.MODE_KANJI     : return 12;
        default :
          throw 'mode:' + mode;
        }

      } else {
        throw 'type:' + type;
      }
    };

    _this.getLostPoint = function(qrcode) {

      var moduleCount = qrcode.getModuleCount();

      var lostPoint = 0;

      // LEVEL1

      for (var row = 0; row < moduleCount; row += 1) {
        for (var col = 0; col < moduleCount; col += 1) {

          var sameCount = 0;
          var dark = qrcode.isDark(row, col);

          for (var r = -1; r <= 1; r += 1) {

            if (row + r < 0 || moduleCount <= row + r) {
              continue;
            }

            for (var c = -1; c <= 1; c += 1) {

              if (col + c < 0 || moduleCount <= col + c) {
                continue;
              }

              if (r == 0 && c == 0) {
                continue;
              }

              if (dark == qrcode.isDark(row + r, col + c) ) {
                sameCount += 1;
              }
            }
          }

          if (sameCount > 5) {
            lostPoint += (3 + sameCount - 5);
          }
        }
      };

      // LEVEL2

      for (var row = 0; row < moduleCount - 1; row += 1) {
        for (var col = 0; col < moduleCount - 1; col += 1) {
          var count = 0;
          if (qrcode.isDark(row, col) ) count += 1;
          if (qrcode.isDark(row + 1, col) ) count += 1;
          if (qrcode.isDark(row, col + 1) ) count += 1;
          if (qrcode.isDark(row + 1, col + 1) ) count += 1;
          if (count == 0 || count == 4) {
            lostPoint += 3;
          }
        }
      }

      // LEVEL3

      for (var row = 0; row < moduleCount; row += 1) {
        for (var col = 0; col < moduleCount - 6; col += 1) {
          if (qrcode.isDark(row, col)
              && !qrcode.isDark(row, col + 1)
              &&  qrcode.isDark(row, col + 2)
              &&  qrcode.isDark(row, col + 3)
              &&  qrcode.isDark(row, col + 4)
              && !qrcode.isDark(row, col + 5)
              &&  qrcode.isDark(row, col + 6) ) {
            lostPoint += 40;
          }
        }
      }

      for (var col = 0; col < moduleCount; col += 1) {
        for (var row = 0; row < moduleCount - 6; row += 1) {
          if (qrcode.isDark(row, col)
              && !qrcode.isDark(row + 1, col)
              &&  qrcode.isDark(row + 2, col)
              &&  qrcode.isDark(row + 3, col)
              &&  qrcode.isDark(row + 4, col)
              && !qrcode.isDark(row + 5, col)
              &&  qrcode.isDark(row + 6, col) ) {
            lostPoint += 40;
          }
        }
      }

      // LEVEL4

      var darkCount = 0;

      for (var col = 0; col < moduleCount; col += 1) {
        for (var row = 0; row < moduleCount; row += 1) {
          if (qrcode.isDark(row, col) ) {
            darkCount += 1;
          }
        }
      }

      var ratio = Math.abs(100 * darkCount / moduleCount / moduleCount - 50) / 5;
      lostPoint += ratio * 10;

      return lostPoint;
    };

    return _this;
  }();

  //---------------------------------------------------------------------
  // QRMath
  //---------------------------------------------------------------------

  var QRMath = function() {

    var EXP_TABLE = new Array(256);
    var LOG_TABLE = new Array(256);

    // initialize tables
    for (var i = 0; i < 8; i += 1) {
      EXP_TABLE[i] = 1 << i;
    }
    for (var i = 8; i < 256; i += 1) {
      EXP_TABLE[i] = EXP_TABLE[i - 4]
        ^ EXP_TABLE[i - 5]
        ^ EXP_TABLE[i - 6]
        ^ EXP_TABLE[i - 8];
    }
    for (var i = 0; i < 255; i += 1) {
      LOG_TABLE[EXP_TABLE[i] ] = i;
    }

    var _this = {};

    _this.glog = function(n) {

      if (n < 1) {
        throw 'glog(' + n + ')';
      }

      return LOG_TABLE[n];
    };

    _this.gexp = function(n) {

      while (n < 0) {
        n += 255;
      }

      while (n >= 256) {
        n -= 255;
      }

      return EXP_TABLE[n];
    };

    return _this;
  }();

  //---------------------------------------------------------------------
  // qrPolynomial
  //---------------------------------------------------------------------

  function qrPolynomial(num, shift) {

    if (typeof num.length == 'undefined') {
      throw num.length + '/' + shift;
    }

    var _num = function() {
      var offset = 0;
      while (offset < num.length && num[offset] == 0) {
        offset += 1;
      }
      var _num = new Array(num.length - offset + shift);
      for (var i = 0; i < num.length - offset; i += 1) {
        _num[i] = num[i + offset];
      }
      return _num;
    }();

    var _this = {};

    _this.getAt = function(index) {
      return _num[index];
    };

    _this.getLength = function() {
      return _num.length;
    };

    _this.multiply = function(e) {

      var num = new Array(_this.getLength() + e.getLength() - 1);

      for (var i = 0; i < _this.getLength(); i += 1) {
        for (var j = 0; j < e.getLength(); j += 1) {
          num[i + j] ^= QRMath.gexp(QRMath.glog(_this.getAt(i) ) + QRMath.glog(e.getAt(j) ) );
        }
      }

      return qrPolynomial(num, 0);
    };

    _this.mod = function(e) {

      if (_this.getLength() - e.getLength() < 0) {
        return _this;
      }

      var ratio = QRMath.glog(_this.getAt(0) ) - QRMath.glog(e.getAt(0) );

      var num = new Array(_this.getLength() );
      for (var i = 0; i < _this.getLength(); i += 1) {
        num[i] = _this.getAt(i);
      }

      for (var i = 0; i < e.getLength(); i += 1) {
        num[i] ^= QRMath.gexp(QRMath.glog(e.getAt(i) ) + ratio);
      }

      // recursive call
      return qrPolynomial(num, 0).mod(e);
    };

    return _this;
  };

  //---------------------------------------------------------------------
  // QRRSBlock
  //---------------------------------------------------------------------

  var QRRSBlock = function() {

    var RS_BLOCK_TABLE = [

      // L
      // M
      // Q
      // H

      // 1
      [1, 26, 19],
      [1, 26, 16],
      [1, 26, 13],
      [1, 26, 9],

      // 2
      [1, 44, 34],
      [1, 44, 28],
      [1, 44, 22],
      [1, 44, 16],

      // 3
      [1, 70, 55],
      [1, 70, 44],
      [2, 35, 17],
      [2, 35, 13],

      // 4
      [1, 100, 80],
      [2, 50, 32],
      [2, 50, 24],
      [4, 25, 9],

      // 5
      [1, 134, 108],
      [2, 67, 43],
      [2, 33, 15, 2, 34, 16],
      [2, 33, 11, 2, 34, 12],

      // 6
      [2, 86, 68],
      [4, 43, 27],
      [4, 43, 19],
      [4, 43, 15],

      // 7
      [2, 98, 78],
      [4, 49, 31],
      [2, 32, 14, 4, 33, 15],
      [4, 39, 13, 1, 40, 14],

      // 8
      [2, 121, 97],
      [2, 60, 38, 2, 61, 39],
      [4, 40, 18, 2, 41, 19],
      [4, 40, 14, 2, 41, 15],

      // 9
      [2, 146, 116],
      [3, 58, 36, 2, 59, 37],
      [4, 36, 16, 4, 37, 17],
      [4, 36, 12, 4, 37, 13],

      // 10
      [2, 86, 68, 2, 87, 69],
      [4, 69, 43, 1, 70, 44],
      [6, 43, 19, 2, 44, 20],
      [6, 43, 15, 2, 44, 16],

      // 11
      [4, 101, 81],
      [1, 80, 50, 4, 81, 51],
      [4, 50, 22, 4, 51, 23],
      [3, 36, 12, 8, 37, 13],

      // 12
      [2, 116, 92, 2, 117, 93],
      [6, 58, 36, 2, 59, 37],
      [4, 46, 20, 6, 47, 21],
      [7, 42, 14, 4, 43, 15],

      // 13
      [4, 133, 107],
      [8, 59, 37, 1, 60, 38],
      [8, 44, 20, 4, 45, 21],
      [12, 33, 11, 4, 34, 12],

      // 14
      [3, 145, 115, 1, 146, 116],
      [4, 64, 40, 5, 65, 41],
      [11, 36, 16, 5, 37, 17],
      [11, 36, 12, 5, 37, 13],

      // 15
      [5, 109, 87, 1, 110, 88],
      [5, 65, 41, 5, 66, 42],
      [5, 54, 24, 7, 55, 25],
      [11, 36, 12, 7, 37, 13],

      // 16
      [5, 122, 98, 1, 123, 99],
      [7, 73, 45, 3, 74, 46],
      [15, 43, 19, 2, 44, 20],
      [3, 45, 15, 13, 46, 16],

      // 17
      [1, 135, 107, 5, 136, 108],
      [10, 74, 46, 1, 75, 47],
      [1, 50, 22, 15, 51, 23],
      [2, 42, 14, 17, 43, 15],

      // 18
      [5, 150, 120, 1, 151, 121],
      [9, 69, 43, 4, 70, 44],
      [17, 50, 22, 1, 51, 23],
      [2, 42, 14, 19, 43, 15],

      // 19
      [3, 141, 113, 4, 142, 114],
      [3, 70, 44, 11, 71, 45],
      [17, 47, 21, 4, 48, 22],
      [9, 39, 13, 16, 40, 14],

      // 20
      [3, 135, 107, 5, 136, 108],
      [3, 67, 41, 13, 68, 42],
      [15, 54, 24, 5, 55, 25],
      [15, 43, 15, 10, 44, 16],

      // 21
      [4, 144, 116, 4, 145, 117],
      [17, 68, 42],
      [17, 50, 22, 6, 51, 23],
      [19, 46, 16, 6, 47, 17],

      // 22
      [2, 139, 111, 7, 140, 112],
      [17, 74, 46],
      [7, 54, 24, 16, 55, 25],
      [34, 37, 13],

      // 23
      [4, 151, 121, 5, 152, 122],
      [4, 75, 47, 14, 76, 48],
      [11, 54, 24, 14, 55, 25],
      [16, 45, 15, 14, 46, 16],

      // 24
      [6, 147, 117, 4, 148, 118],
      [6, 73, 45, 14, 74, 46],
      [11, 54, 24, 16, 55, 25],
      [30, 46, 16, 2, 47, 17],

      // 25
      [8, 132, 106, 4, 133, 107],
      [8, 75, 47, 13, 76, 48],
      [7, 54, 24, 22, 55, 25],
      [22, 45, 15, 13, 46, 16],

      // 26
      [10, 142, 114, 2, 143, 115],
      [19, 74, 46, 4, 75, 47],
      [28, 50, 22, 6, 51, 23],
      [33, 46, 16, 4, 47, 17],

      // 27
      [8, 152, 122, 4, 153, 123],
      [22, 73, 45, 3, 74, 46],
      [8, 53, 23, 26, 54, 24],
      [12, 45, 15, 28, 46, 16],

      // 28
      [3, 147, 117, 10, 148, 118],
      [3, 73, 45, 23, 74, 46],
      [4, 54, 24, 31, 55, 25],
      [11, 45, 15, 31, 46, 16],

      // 29
      [7, 146, 116, 7, 147, 117],
      [21, 73, 45, 7, 74, 46],
      [1, 53, 23, 37, 54, 24],
      [19, 45, 15, 26, 46, 16],

      // 30
      [5, 145, 115, 10, 146, 116],
      [19, 75, 47, 10, 76, 48],
      [15, 54, 24, 25, 55, 25],
      [23, 45, 15, 25, 46, 16],

      // 31
      [13, 145, 115, 3, 146, 116],
      [2, 74, 46, 29, 75, 47],
      [42, 54, 24, 1, 55, 25],
      [23, 45, 15, 28, 46, 16],

      // 32
      [17, 145, 115],
      [10, 74, 46, 23, 75, 47],
      [10, 54, 24, 35, 55, 25],
      [19, 45, 15, 35, 46, 16],

      // 33
      [17, 145, 115, 1, 146, 116],
      [14, 74, 46, 21, 75, 47],
      [29, 54, 24, 19, 55, 25],
      [11, 45, 15, 46, 46, 16],

      // 34
      [13, 145, 115, 6, 146, 116],
      [14, 74, 46, 23, 75, 47],
      [44, 54, 24, 7, 55, 25],
      [59, 46, 16, 1, 47, 17],

      // 35
      [12, 151, 121, 7, 152, 122],
      [12, 75, 47, 26, 76, 48],
      [39, 54, 24, 14, 55, 25],
      [22, 45, 15, 41, 46, 16],

      // 36
      [6, 151, 121, 14, 152, 122],
      [6, 75, 47, 34, 76, 48],
      [46, 54, 24, 10, 55, 25],
      [2, 45, 15, 64, 46, 16],

      // 37
      [17, 152, 122, 4, 153, 123],
      [29, 74, 46, 14, 75, 47],
      [49, 54, 24, 10, 55, 25],
      [24, 45, 15, 46, 46, 16],

      // 38
      [4, 152, 122, 18, 153, 123],
      [13, 74, 46, 32, 75, 47],
      [48, 54, 24, 14, 55, 25],
      [42, 45, 15, 32, 46, 16],

      // 39
      [20, 147, 117, 4, 148, 118],
      [40, 75, 47, 7, 76, 48],
      [43, 54, 24, 22, 55, 25],
      [10, 45, 15, 67, 46, 16],

      // 40
      [19, 148, 118, 6, 149, 119],
      [18, 75, 47, 31, 76, 48],
      [34, 54, 24, 34, 55, 25],
      [20, 45, 15, 61, 46, 16]
    ];

    var qrRSBlock = function(totalCount, dataCount) {
      var _this = {};
      _this.totalCount = totalCount;
      _this.dataCount = dataCount;
      return _this;
    };

    var _this = {};

    var getRsBlockTable = function(typeNumber, errorCorrectionLevel) {

      switch(errorCorrectionLevel) {
      case QRErrorCorrectionLevel.L :
        return RS_BLOCK_TABLE[(typeNumber - 1) * 4 + 0];
      case QRErrorCorrectionLevel.M :
        return RS_BLOCK_TABLE[(typeNumber - 1) * 4 + 1];
      case QRErrorCorrectionLevel.Q :
        return RS_BLOCK_TABLE[(typeNumber - 1) * 4 + 2];
      case QRErrorCorrectionLevel.H :
        return RS_BLOCK_TABLE[(typeNumber - 1) * 4 + 3];
      default :
        return undefined;
      }
    };

    _this.getRSBlocks = function(typeNumber, errorCorrectionLevel) {

      var rsBlock = getRsBlockTable(typeNumber, errorCorrectionLevel);

      if (typeof rsBlock == 'undefined') {
        throw 'bad rs block @ typeNumber:' + typeNumber +
            '/errorCorrectionLevel:' + errorCorrectionLevel;
      }

      var length = rsBlock.length / 3;

      var list = [];

      for (var i = 0; i < length; i += 1) {

        var count = rsBlock[i * 3 + 0];
        var totalCount = rsBlock[i * 3 + 1];
        var dataCount = rsBlock[i * 3 + 2];

        for (var j = 0; j < count; j += 1) {
          list.push(qrRSBlock(totalCount, dataCount) );
        }
      }

      return list;
    };

    return _this;
  }();

  //---------------------------------------------------------------------
  // qrBitBuffer
  //---------------------------------------------------------------------

  var qrBitBuffer = function() {

    var _buffer = [];
    var _length = 0;

    var _this = {};

    _this.getBuffer = function() {
      return _buffer;
    };

    _this.getAt = function(index) {
      var bufIndex = Math.floor(index / 8);
      return ( (_buffer[bufIndex] >>> (7 - index % 8) ) & 1) == 1;
    };

    _this.put = function(num, length) {
      for (var i = 0; i < length; i += 1) {
        _this.putBit( ( (num >>> (length - i - 1) ) & 1) == 1);
      }
    };

    _this.getLengthInBits = function() {
      return _length;
    };

    _this.putBit = function(bit) {

      var bufIndex = Math.floor(_length / 8);
      if (_buffer.length <= bufIndex) {
        _buffer.push(0);
      }

      if (bit) {
        _buffer[bufIndex] |= (0x80 >>> (_length % 8) );
      }

      _length += 1;
    };

    return _this;
  };

  //---------------------------------------------------------------------
  // qrNumber
  //---------------------------------------------------------------------

  var qrNumber = function(data) {

    var _mode = QRMode.MODE_NUMBER;
    var _data = data;

    var _this = {};

    _this.getMode = function() {
      return _mode;
    };

    _this.getLength = function(buffer) {
      return _data.length;
    };

    _this.write = function(buffer) {

      var data = _data;

      var i = 0;

      while (i + 2 < data.length) {
        buffer.put(strToNum(data.substring(i, i + 3) ), 10);
        i += 3;
      }

      if (i < data.length) {
        if (data.length - i == 1) {
          buffer.put(strToNum(data.substring(i, i + 1) ), 4);
        } else if (data.length - i == 2) {
          buffer.put(strToNum(data.substring(i, i + 2) ), 7);
        }
      }
    };

    var strToNum = function(s) {
      var num = 0;
      for (var i = 0; i < s.length; i += 1) {
        num = num * 10 + chatToNum(s.charAt(i) );
      }
      return num;
    };

    var chatToNum = function(c) {
      if ('0' <= c && c <= '9') {
        return c.charCodeAt(0) - '0'.charCodeAt(0);
      }
      throw 'illegal char :' + c;
    };

    return _this;
  };

  //---------------------------------------------------------------------
  // qrAlphaNum
  //---------------------------------------------------------------------

  var qrAlphaNum = function(data) {

    var _mode = QRMode.MODE_ALPHA_NUM;
    var _data = data;

    var _this = {};

    _this.getMode = function() {
      return _mode;
    };

    _this.getLength = function(buffer) {
      return _data.length;
    };

    _this.write = function(buffer) {

      var s = _data;

      var i = 0;

      while (i + 1 < s.length) {
        buffer.put(
          getCode(s.charAt(i) ) * 45 +
          getCode(s.charAt(i + 1) ), 11);
        i += 2;
      }

      if (i < s.length) {
        buffer.put(getCode(s.charAt(i) ), 6);
      }
    };

    var getCode = function(c) {

      if ('0' <= c && c <= '9') {
        return c.charCodeAt(0) - '0'.charCodeAt(0);
      } else if ('A' <= c && c <= 'Z') {
        return c.charCodeAt(0) - 'A'.charCodeAt(0) + 10;
      } else {
        switch (c) {
        case ' ' : return 36;
        case '$' : return 37;
        case '%' : return 38;
        case '*' : return 39;
        case '+' : return 40;
        case '-' : return 41;
        case '.' : return 42;
        case '/' : return 43;
        case ':' : return 44;
        default :
          throw 'illegal char :' + c;
        }
      }
    };

    return _this;
  };

  //---------------------------------------------------------------------
  // qr8BitByte
  //---------------------------------------------------------------------

  var qr8BitByte = function(data) {

    var _mode = QRMode.MODE_8BIT_BYTE;
    var _data = data;
    var _bytes = qrcode.stringToBytes(data);

    var _this = {};

    _this.getMode = function() {
      return _mode;
    };

    _this.getLength = function(buffer) {
      return _bytes.length;
    };

    _this.write = function(buffer) {
      for (var i = 0; i < _bytes.length; i += 1) {
        buffer.put(_bytes[i], 8);
      }
    };

    return _this;
  };

  //---------------------------------------------------------------------
  // qrKanji
  //---------------------------------------------------------------------

  var qrKanji = function(data) {

    var _mode = QRMode.MODE_KANJI;
    var _data = data;

    var stringToBytes = qrcode.stringToBytesFuncs['SJIS'];
    if (!stringToBytes) {
      throw 'sjis not supported.';
    }
    !function(c, code) {
      // self test for sjis support.
      var test = stringToBytes(c);
      if (test.length != 2 || ( (test[0] << 8) | test[1]) != code) {
        throw 'sjis not supported.';
      }
    }('\u53cb', 0x9746);

    var _bytes = stringToBytes(data);

    var _this = {};

    _this.getMode = function() {
      return _mode;
    };

    _this.getLength = function(buffer) {
      return ~~(_bytes.length / 2);
    };

    _this.write = function(buffer) {

      var data = _bytes;

      var i = 0;

      while (i + 1 < data.length) {

        var c = ( (0xff & data[i]) << 8) | (0xff & data[i + 1]);

        if (0x8140 <= c && c <= 0x9FFC) {
          c -= 0x8140;
        } else if (0xE040 <= c && c <= 0xEBBF) {
          c -= 0xC140;
        } else {
          throw 'illegal char at ' + (i + 1) + '/' + c;
        }

        c = ( (c >>> 8) & 0xff) * 0xC0 + (c & 0xff);

        buffer.put(c, 13);

        i += 2;
      }

      if (i < data.length) {
        throw 'illegal char at ' + (i + 1);
      }
    };

    return _this;
  };

  //=====================================================================
  // GIF Support etc.
  //

  //---------------------------------------------------------------------
  // byteArrayOutputStream
  //---------------------------------------------------------------------

  var byteArrayOutputStream = function() {

    var _bytes = [];

    var _this = {};

    _this.writeByte = function(b) {
      _bytes.push(b & 0xff);
    };

    _this.writeShort = function(i) {
      _this.writeByte(i);
      _this.writeByte(i >>> 8);
    };

    _this.writeBytes = function(b, off, len) {
      off = off || 0;
      len = len || b.length;
      for (var i = 0; i < len; i += 1) {
        _this.writeByte(b[i + off]);
      }
    };

    _this.writeString = function(s) {
      for (var i = 0; i < s.length; i += 1) {
        _this.writeByte(s.charCodeAt(i) );
      }
    };

    _this.toByteArray = function() {
      return _bytes;
    };

    _this.toString = function() {
      var s = '';
      s += '[';
      for (var i = 0; i < _bytes.length; i += 1) {
        if (i > 0) {
          s += ',';
        }
        s += _bytes[i];
      }
      s += ']';
      return s;
    };

    return _this;
  };

  //---------------------------------------------------------------------
  // base64EncodeOutputStream
  //---------------------------------------------------------------------

  var base64EncodeOutputStream = function() {

    var _buffer = 0;
    var _buflen = 0;
    var _length = 0;
    var _base64 = '';

    var _this = {};

    var writeEncoded = function(b) {
      _base64 += String.fromCharCode(encode(b & 0x3f) );
    };

    var encode = function(n) {
      if (n < 0) {
        // error.
      } else if (n < 26) {
        return 0x41 + n;
      } else if (n < 52) {
        return 0x61 + (n - 26);
      } else if (n < 62) {
        return 0x30 + (n - 52);
      } else if (n == 62) {
        return 0x2b;
      } else if (n == 63) {
        return 0x2f;
      }
      throw 'n:' + n;
    };

    _this.writeByte = function(n) {

      _buffer = (_buffer << 8) | (n & 0xff);
      _buflen += 8;
      _length += 1;

      while (_buflen >= 6) {
        writeEncoded(_buffer >>> (_buflen - 6) );
        _buflen -= 6;
      }
    };

    _this.flush = function() {

      if (_buflen > 0) {
        writeEncoded(_buffer << (6 - _buflen) );
        _buffer = 0;
        _buflen = 0;
      }

      if (_length % 3 != 0) {
        // padding
        var padlen = 3 - _length % 3;
        for (var i = 0; i < padlen; i += 1) {
          _base64 += '=';
        }
      }
    };

    _this.toString = function() {
      return _base64;
    };

    return _this;
  };

  //---------------------------------------------------------------------
  // base64DecodeInputStream
  //---------------------------------------------------------------------

  var base64DecodeInputStream = function(str) {

    var _str = str;
    var _pos = 0;
    var _buffer = 0;
    var _buflen = 0;

    var _this = {};

    _this.read = function() {

      while (_buflen < 8) {

        if (_pos >= _str.length) {
          if (_buflen == 0) {
            return -1;
          }
          throw 'unexpected end of file./' + _buflen;
        }

        var c = _str.charAt(_pos);
        _pos += 1;

        if (c == '=') {
          _buflen = 0;
          return -1;
        } else if (c.match(/^\s$/) ) {
          // ignore if whitespace.
          continue;
        }

        _buffer = (_buffer << 6) | decode(c.charCodeAt(0) );
        _buflen += 6;
      }

      var n = (_buffer >>> (_buflen - 8) ) & 0xff;
      _buflen -= 8;
      return n;
    };

    var decode = function(c) {
      if (0x41 <= c && c <= 0x5a) {
        return c - 0x41;
      } else if (0x61 <= c && c <= 0x7a) {
        return c - 0x61 + 26;
      } else if (0x30 <= c && c <= 0x39) {
        return c - 0x30 + 52;
      } else if (c == 0x2b) {
        return 62;
      } else if (c == 0x2f) {
        return 63;
      } else {
        throw 'c:' + c;
      }
    };

    return _this;
  };

  //---------------------------------------------------------------------
  // gifImage (B/W)
  //---------------------------------------------------------------------

  var gifImage = function(width, height) {

    var _width = width;
    var _height = height;
    var _data = new Array(width * height);

    var _this = {};

    _this.setPixel = function(x, y, pixel) {
      _data[y * _width + x] = pixel;
    };

    _this.write = function(out) {

      //---------------------------------
      // GIF Signature

      out.writeString('GIF87a');

      //---------------------------------
      // Screen Descriptor

      out.writeShort(_width);
      out.writeShort(_height);

      out.writeByte(0x80); // 2bit
      out.writeByte(0);
      out.writeByte(0);

      //---------------------------------
      // Global Color Map

      // black
      out.writeByte(0x00);
      out.writeByte(0x00);
      out.writeByte(0x00);

      // white
      out.writeByte(0xff);
      out.writeByte(0xff);
      out.writeByte(0xff);

      //---------------------------------
      // Image Descriptor

      out.writeString(',');
      out.writeShort(0);
      out.writeShort(0);
      out.writeShort(_width);
      out.writeShort(_height);
      out.writeByte(0);

      //---------------------------------
      // Local Color Map

      //---------------------------------
      // Raster Data

      var lzwMinCodeSize = 2;
      var raster = getLZWRaster(lzwMinCodeSize);

      out.writeByte(lzwMinCodeSize);

      var offset = 0;

      while (raster.length - offset > 255) {
        out.writeByte(255);
        out.writeBytes(raster, offset, 255);
        offset += 255;
      }

      out.writeByte(raster.length - offset);
      out.writeBytes(raster, offset, raster.length - offset);
      out.writeByte(0x00);

      //---------------------------------
      // GIF Terminator
      out.writeString(';');
    };

    var bitOutputStream = function(out) {

      var _out = out;
      var _bitLength = 0;
      var _bitBuffer = 0;

      var _this = {};

      _this.write = function(data, length) {

        if ( (data >>> length) != 0) {
          throw 'length over';
        }

        while (_bitLength + length >= 8) {
          _out.writeByte(0xff & ( (data << _bitLength) | _bitBuffer) );
          length -= (8 - _bitLength);
          data >>>= (8 - _bitLength);
          _bitBuffer = 0;
          _bitLength = 0;
        }

        _bitBuffer = (data << _bitLength) | _bitBuffer;
        _bitLength = _bitLength + length;
      };

      _this.flush = function() {
        if (_bitLength > 0) {
          _out.writeByte(_bitBuffer);
        }
      };

      return _this;
    };

    var getLZWRaster = function(lzwMinCodeSize) {

      var clearCode = 1 << lzwMinCodeSize;
      var endCode = (1 << lzwMinCodeSize) + 1;
      var bitLength = lzwMinCodeSize + 1;

      // Setup LZWTable
      var table = lzwTable();

      for (var i = 0; i < clearCode; i += 1) {
        table.add(String.fromCharCode(i) );
      }
      table.add(String.fromCharCode(clearCode) );
      table.add(String.fromCharCode(endCode) );

      var byteOut = byteArrayOutputStream();
      var bitOut = bitOutputStream(byteOut);

      // clear code
      bitOut.write(clearCode, bitLength);

      var dataIndex = 0;

      var s = String.fromCharCode(_data[dataIndex]);
      dataIndex += 1;

      while (dataIndex < _data.length) {

        var c = String.fromCharCode(_data[dataIndex]);
        dataIndex += 1;

        if (table.contains(s + c) ) {

          s = s + c;

        } else {

          bitOut.write(table.indexOf(s), bitLength);

          if (table.size() < 0xfff) {

            if (table.size() == (1 << bitLength) ) {
              bitLength += 1;
            }

            table.add(s + c);
          }

          s = c;
        }
      }

      bitOut.write(table.indexOf(s), bitLength);

      // end code
      bitOut.write(endCode, bitLength);

      bitOut.flush();

      return byteOut.toByteArray();
    };

    var lzwTable = function() {

      var _map = {};
      var _size = 0;

      var _this = {};

      _this.add = function(key) {
        if (_this.contains(key) ) {
          throw 'dup key:' + key;
        }
        _map[key] = _size;
        _size += 1;
      };

      _this.size = function() {
        return _size;
      };

      _this.indexOf = function(key) {
        return _map[key];
      };

      _this.contains = function(key) {
        return typeof _map[key] != 'undefined';
      };

      return _this;
    };

    return _this;
  };

  var createDataURL = function(width, height, getPixel) {
    var gif = gifImage(width, height);
    for (var y = 0; y < height; y += 1) {
      for (var x = 0; x < width; x += 1) {
        gif.setPixel(x, y, getPixel(x, y) );
      }
    }

    var b = byteArrayOutputStream();
    gif.write(b);

    var base64 = base64EncodeOutputStream();
    var bytes = b.toByteArray();
    for (var i = 0; i < bytes.length; i += 1) {
      base64.writeByte(bytes[i]);
    }
    base64.flush();

    return 'data:image/gif;base64,' + base64;
  };

  //---------------------------------------------------------------------
  // returns qrcode function.

  return qrcode;
}();
</script>
<script>
function rwShowError(msg){
  try{
    let bar = document.getElementById("errBar");
    if(!bar){
      bar = document.createElement("div"); bar.id = "errBar"; bar.className = "err-bar";
      bar.innerHTML = '<span></span><button type="button">Ausblenden</button>';
      bar.querySelector("button").onclick = function(){ bar.remove(); };
      document.body.appendChild(bar);
    }
    bar.querySelector("span").textContent = "Fehler: " + msg + " – bitte Seite neu laden. Ihre Daten bleiben erhalten.";
  }catch(e){}
}
window.addEventListener("error", function(e){ rwShowError(e.message || "Unbekannt"); });
window.addEventListener("unhandledrejection", function(e){ rwShowError((e.reason && e.reason.message) || String(e.reason)); });
(function(){
"use strict";

/* ================= Grundlagen ================= */
const STAGES = [
  {id:"neu",            no:"01", title:"Neuer",       it:"Lead."},
  {id:"nicht_erreicht", no:"02", title:"Telefonisch", it:"nicht erreicht."},
  {id:"nachhaken",      no:"03", title:"Nach",        it:"haken."},
  {id:"email",          no:"04", title:"E-Mail",      it:"raus."},
  {id:"termin",         no:"05", title:"Ersttermin",  it:"gebucht."},
  {id:"closed",         no:"06", title:"Geclosed.",   it:""}
];
const STAGE_NAME = {
  neu:"Neuer Lead", nicht_erreicht:"Telefonisch nicht erreicht", nachhaken:"Nachhaken",
  email:"E-Mail raus", termin:"Ersttermin gebucht", closed:"Geclosed"
};
const KEY = "raumwerk-crm-v1";

const DEFAULT_SUBJECT = "Ihre Immobilien – als ruhige Roomtour aus vorhandenen Fotos";
const DEFAULT_BODY =
`{{begruessung}},

ich bin auf Ihre aktuellen Objekte aufmerksam geworden und möchte Ihnen kurz raumwerk vorstellen.

Aus Ihren vorhandenen Fotos gestalten wir ruhige, stimmige Immobilienvideos – als geführte Roomtour für Ihre Website, das Exposé und Social Media. Auf Wunsch verfeinern wir zusätzlich Licht und Farben oder richten leere Räume virtuell ein. Ihre Immobilie bleibt dabei immer wiedererkennbar.

Gern zeige ich Ihnen an einem Beispiel, wie das bei einem Ihrer Objekte aussehen könnte.

Hätten Sie in den nächsten Tagen 15 Minuten Zeit für ein kurzes Gespräch?

Herzliche Grüße
{{absender}}

raumwerk
ws-strategy.de`;

const TPL_TERMIN_SUBJECT = "Terminbestätigung: unser Gespräch am {{datum}}";
const TPL_TERMIN_BODY =
`{{begruessung}},

vielen Dank für das angenehme Gespräch. Hiermit bestätige ich Ihnen gern unseren Termin:

Datum: {{datum}}
Uhrzeit: {{uhrzeit}} Uhr
Ort: Online-Meeting
Link zum Meeting: {{link}}

Im Gespräch zeige ich Ihnen, wie aus Ihren vorhandenen Objektfotos ruhige, hochwertige Immobilienvideos entstehen – und wie das konkret bei einem Ihrer aktuellen Objekte aussehen könnte. Wenn Sie möchten, wählen Sie dafür vorab gern ein Objekt aus.

Sollte Ihnen der Termin doch nicht passen, antworten Sie einfach kurz auf diese E-Mail – wir finden gern einen neuen.

Ich freue mich auf unser Gespräch.

Herzliche Grüße
{{absender}}
{{absender_telefon}}

raumwerk
ws-strategy.de`;

const TPL_CALL_SUBJECT = "Danke für das Gespräch – raumwerk auf einen Blick";
const TPL_CALL_BODY =
`{{begruessung}},

vielen Dank für das nette Telefonat. Hier noch einmal alles Wichtige zu raumwerk auf einen Blick.

raumwerk hilft Immobilienmaklern, ihre Objekte so zu präsentieren, wie sie es verdienen: mit Sorgfalt, mit Charakter und mit einem Blick fürs Detail. Wir verbinden moderne KI-Technologie mit einem klaren Gespür für Räume und Atmosphäre. So entstehen Präsentationen, die Interessenten berühren und Ihre Immobilien aus der Masse herausheben – ohne zusätzlichen Aufwand für Sie.

IMMOBILIENVIDEOS – UNSER KERNANGEBOT
Aus Ihren Objektfotos gestalten wir ein ruhiges, stimmiges Video, eine geführte Roomtour durch die Immobilie. So wird aus einzelnen Bildern ein Rundgang, der die Atmosphäre und Wirkung der Räume spürbar macht. Ihr Objekt fällt auf und bleibt im Gedächtnis. Ein neuer Fototermin vor Ort ist dafür nicht nötig.

BILDOPTIMIERUNG – ALS ERGÄNZUNG
Wir verfeinern Licht, Farben und Details Ihrer Fotos und erhöhen per Upscaling die Auflösung. Dunkle oder blasse Aufnahmen wirken danach hell, klar und hochwertig. So zeigt sich Ihre Immobilie von ihrer besten Seite.

KI-MÖBLIERUNG – ALS ERGÄNZUNG
Leere Räume richten wir virtuell und stilvoll ein, als Bild oder als Roomtour. Interessenten sehen so sofort, wie sich die Räume nutzen lassen und wie wohnlich sie wirken können. Gerade leerstehende Objekte gewinnen dadurch deutlich an Ausstrahlung.

ALLES KOMBINIERBAR
Bildoptimierung und KI-Möblierung lassen sich einzeln buchen oder direkt in Ihr Immobilienvideo einbauen. Alle drei Angebote können Sie frei kombinieren, ganz wie es zu Ihrem Objekt passt.

Ihre Immobilie bleibt dabei immer wiedererkennbar.

So sieht das aus – ein Beispielvideo:
{{video}}

Bei Interesse rufen Sie mich gern an unter {{absender_telefon}} oder antworten einfach auf diese E-Mail. Gern stelle ich Ihnen raumwerk auch in einem kurzen 10-minütigen Gespräch persönlich vor.

Herzliche Grüße
{{absender}}

raumwerk
ws-strategy.de`;

const TPL_CALL_SUBJECT_V1 = "Wie besprochen: raumwerk und ein Beispielvideo";
const TPL_CALL_BODY_V1 =
`{{begruessung}},

vielen Dank für das nette Telefonat. Wie versprochen erhalten Sie hier alles Wichtige auf einen Blick.

Was wir machen
Aus Ihren vorhandenen Objektfotos gestalten wir ruhige, stimmige Immobilienvideos – als geführte Roomtour für Ihre Website, das Exposé und Social Media. Ein neuer Fototermin vor Ort ist dafür nicht nötig.

Auf Wunsch zusätzlich
– Bildoptimierung: Licht, Farben und Details verfeinern, inklusive Upscaling für eine höhere Auflösung
– KI-Möblierung: leere Räume stilvoll einrichten, als Bild oder als Roomtour

Ihre Immobilie bleibt dabei immer wiedererkennbar.

So sieht das aus – ein Beispielvideo:
{{video}}

Wenn Sie möchten, zeige ich Ihnen in einem kurzen Gespräch, wie das bei einem Ihrer aktuellen Objekte aussehen könnte. Antworten Sie einfach auf diese E-Mail oder rufen Sie mich an.

Herzliche Grüße
{{absender}}
{{absender_telefon}}

raumwerk
ws-strategy.de`;

function defaultTemplates(){
  return [
    {id:"erstkontakt",   name:"Erstkontakt",        subject:DEFAULT_SUBJECT,    body:DEFAULT_BODY,    stage:"email"},
    {id:"termin",        name:"Terminbestätigung",  subject:TPL_TERMIN_SUBJECT, body:TPL_TERMIN_BODY, stage:"termin"},
    {id:"nachtelefonat", name:"Nach dem Telefonat", subject:TPL_CALL_SUBJECT,   body:TPL_CALL_BODY,   stage:"email"}
  ];
}
const PLACEHOLDERS = ["begruessung","vorname","nachname","name","firma","ort","datum","uhrzeit","termin","link","video","absender","absender_telefon"];

const $ = (s, r=document) => r.querySelector(s);
const $$ = (s, r=document) => Array.from(r.querySelectorAll(s));
const esc = s => String(s ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2,8);
const now = () => new Date().toISOString();

const ICON = {
  phone:'<svg class="i" viewBox="0 0 24 24"><path d="M6.5 3.5h3l1.5 4-2 1.5a11 11 0 0 0 6 6l1.5-2 4 1.5v3a2 2 0 0 1-2 2A16 16 0 0 1 4.5 5.5a2 2 0 0 1 2-2z"/></svg>',
  mail:'<svg class="i" viewBox="0 0 24 24"><rect x="3.5" y="5.5" width="17" height="13" rx="1.5"/><path d="M4 7l8 6 8-6"/></svg>',
  pin:'<svg class="i" viewBox="0 0 24 24"><path d="M12 21s-6.5-5.6-6.5-11a6.5 6.5 0 0 1 13 0c0 5.4-6.5 11-6.5 11z"/><circle cx="12" cy="10" r="2.2"/></svg>',
  web:'<svg class="i" viewBox="0 0 24 24"><circle cx="12" cy="12" r="8.5"/><path d="M3.5 12h17M12 3.5c2.5 2.6 3.5 5.4 3.5 8.5s-1 5.9-3.5 8.5c-2.5-2.6-3.5-5.4-3.5-8.5s1-5.9 3.5-8.5z"/></svg>',
  arrow:'<svg class="i arr" viewBox="0 0 24 24"><path d="M7 17L17 7M9 7h8v8"/></svg>',
  cal:'<svg class="i" viewBox="0 0 24 24"><rect x="4" y="5.5" width="16" height="14" rx="1.5"/><path d="M4 10h16M8.5 3.5v4M15.5 3.5v4"/></svg>',
  x:'<svg class="i" viewBox="0 0 24 24"><path d="M7 7l10 10M17 7L7 17"/></svg>',
  retry:'<svg class="i" viewBox="0 0 24 24"><path d="M4.5 12a7.5 7.5 0 1 0 2.2-5.3M4.5 4.5v4h4"/></svg>',
  check:'<svg class="i" viewBox="0 0 24 24"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg>'
};

/* ================= Speicher ================= */
function defaultDb(){
  return {version:1, leads:[], settings:{
    subject:DEFAULT_SUBJECT, body:DEFAULT_BODY, mode:"auto", account:"0", sender:"", senderPhone:"", video:"", lastBackup:null, fields:[], templates:null
  }};
}
// Lokaler Modus: Das Python-Skript liefert die Seite aus und speichert in eine Datei.
const SERVER = !!window.RW_SERVER;
let ACCESS_KEY = "";
try{
  ACCESS_KEY = new URLSearchParams(location.search).get("k") || localStorage.getItem("raumwerk-key") || "";
  if(ACCESS_KEY) localStorage.setItem("raumwerk-key", ACCESS_KEY);
}catch(_){}
function api(opts){
  opts = opts || {};
  opts.headers = Object.assign({}, opts.headers || {}, ACCESS_KEY ? {"X-Raumwerk-Key": ACCESS_KEY} : {});
  return fetch("/api/daten", opts);
}
const REMOTE = SERVER && window.RW_LOCAL === false;   // Handy/Tablet greift auf den Computer zu
function normalize(d){
  const base = defaultDb();
  d = (d && typeof d === "object") ? d : {};
  d.version = 1;
  d.settings = Object.assign(base.settings, d.settings || {});
  d.leads = Array.isArray(d.leads) ? d.leads : [];
  if(!Array.isArray(d.settings.fields)) d.settings.fields = [];
  if(!Array.isArray(d.settings.templates) || !d.settings.templates.length){
    // Umstieg von der einzelnen Vorlage: bisherigen Text als „Erstkontakt“ übernehmen
    d.settings.templates = defaultTemplates();
    d.settings.templates[0].subject = d.settings.subject || DEFAULT_SUBJECT;
    d.settings.templates[0].body = d.settings.body || DEFAULT_BODY;
  }
  // Unveränderte erste Fassung von „Nach dem Telefonat“ auf den neuen Text heben
  d.settings.templates.forEach(t => {
    if(t.id === "nachtelefonat" && t.body === TPL_CALL_BODY_V1 && t.subject === TPL_CALL_SUBJECT_V1){
      t.subject = TPL_CALL_SUBJECT; t.body = TPL_CALL_BODY;
    }
  });
  // Felder, die nur an Leads hängen, in die Liste aufnehmen
  d.leads.forEach(l => Object.keys(l.extra || {}).forEach(k => { if(!d.settings.fields.includes(k)) d.settings.fields.push(k); }));
  return d;
}
let db = SERVER ? defaultDb() : load();
let loaded = !SERVER;
function load(){
  try{
    const raw = localStorage.getItem(KEY);
    if(raw) return normalize(JSON.parse(raw));
  }catch(e){ console.warn(e); }
  return defaultDb();
}
let storageOk = true;
let rev = 0, dirty = false, pushing = false, pushTimer = null, retryTimer = null;
function save(){
  if(!loaded) return;          // nie leere Daten über die Datei schreiben
  if(SERVER){
    dirty = true;
    clearTimeout(pushTimer);
    pushTimer = setTimeout(push, 250);
    return;
  }
  try{ localStorage.setItem(KEY, JSON.stringify(db)); storageOk = true; }
  catch(e){
    if(storageOk) toast("Diese Ansicht kann nicht dauerhaft speichern – bitte die Seite direkt im Browser öffnen.");
    storageOk = false;
  }
}
function push(keepalive){
  if(!dirty || (pushing && !keepalive)) return;
  const force = pushing;        // Seite wird geschlossen, während noch gespeichert wird
  pushing = true; dirty = false;
  clearTimeout(retryTimer);
  return api({
    method:"POST", keepalive:!!keepalive,
    headers:{"Content-Type":"application/json", "X-Raumwerk":"1"},
    body:JSON.stringify({rev, force, data:db})
  }).then(r => {
    if(r.status === 409){
      // Ein anderes Fenster hat inzwischen gespeichert: beide Stände zusammenführen
      return api({cache:"no-store"}).then(x => x.json()).then(j => {
        db = normalize(mergeDb(normalize(j.data), db)); rev = j.rev; dirty = true; storageOk = true;
        render(); if(openId) renderDetail();
        toast("Änderungen aus einem anderen Fenster übernommen.");
      });
    }
    if(!r.ok) throw new Error("HTTP " + r.status);
    return r.json().then(j => { rev = j.rev; storageOk = true; });
  }).catch(() => {
    dirty = true;
    if(storageOk) toast(REMOTE ? "Computer nicht erreichbar – gleiches WLAN? Neuer Versuch läuft." : "Speichern fehlgeschlagen – läuft das Python-Fenster noch? Neuer Versuch läuft.");
    storageOk = false;
    retryTimer = setTimeout(push, 4000);
  }).finally(() => {
    pushing = false;
    if(dirty && storageOk) push();
  });
}
function mergeDb(server, local){
  const gone = new Set([...(server.deleted||[]), ...(local.deleted||[])]);
  const map = new Map();
  server.leads.forEach(l => { if(!gone.has(l.id)) map.set(l.id, l); });
  local.leads.forEach(l => {
    if(gone.has(l.id)) return;
    const o = map.get(l.id);
    if(!o){ map.set(l.id, l); return; }
    const newer = (l.updated||"") >= (o.updated||"") ? l : o, older = newer === l ? o : l;
    const ids = new Set((newer.notes||[]).map(n => n.id));
    const notes = [...(newer.notes||[]), ...(older.notes||[]).filter(n => !ids.has(n.id))]
      .filter(n => !gone.has(n.id)).sort((a,b) => a.ts < b.ts ? 1 : a.ts > b.ts ? -1 : 0);
    map.set(l.id, Object.assign({}, newer, {notes}));
  });
  return Object.assign({}, local, {leads:[...map.values()], deleted:[...gone].slice(-2000)});
}
function forget(id){ db.deleted = (db.deleted || []).concat(id).slice(-2000); }
function fetchData(){
  return api({cache:"no-store"})
    .then(r => { if(!r.ok) throw new Error("HTTP " + r.status); return r.json(); })
    .then(j => { db = normalize(j.data); rev = j.rev; loaded = true; render(); });
}
const byId = id => db.leads.find(l => l.id === id);

/* ================= Hilfen ================= */
function fmtDate(iso, withTime=true){
  if(!iso) return "";
  const d = new Date(iso);
  const date = d.toLocaleDateString("de-DE",{day:"numeric",month:"short",year: d.getFullYear()!==new Date().getFullYear() ? "numeric" : undefined});
  return withTime ? date + ", " + d.toLocaleTimeString("de-DE",{hour:"2-digit",minute:"2-digit"}) + " Uhr" : date;
}
function dayDiff(iso){
  const a = new Date(iso); a.setHours(0,0,0,0);
  const b = new Date(); b.setHours(0,0,0,0);
  return Math.round((b - a) / 864e5);
}
function rel(iso){
  const d = dayDiff(iso);
  if(d <= 0) return "heute";
  if(d === 1) return "gestern";
  if(d < 7) return "vor " + d + " Tagen";
  if(d < 14) return "vor 1 Woche";
  if(d < 60) return "vor " + Math.floor(d/7) + " Wochen";
  return fmtDate(iso, false);
}
function todayStr(){ const d=new Date(); return d.getFullYear()+"-"+String(d.getMonth()+1).padStart(2,"0")+"-"+String(d.getDate()).padStart(2,"0"); }
function dueInfo(l){
  if(!l.wiedervorlage || l.stage === "closed") return null;
  const t = todayStr();
  if(l.wiedervorlage < t) return {cls:"warm", text:"Wiedervorlage überfällig"};
  if(l.wiedervorlage === t) return {cls:"warm", text:"Wiedervorlage heute"};
  const d = new Date(l.wiedervorlage + "T00:00");
  return {cls:"", text:"Wiedervorlage " + d.toLocaleDateString("de-DE",{day:"numeric",month:"short"})};
}
function splitName(n){
  const parts = String(n||"").trim().split(/\s+/).filter(Boolean);
  if(!parts.length) return {vor:"", nach:""};
  if(parts.length === 1) return {vor:"", nach:parts[0]};
  return {vor:parts[0], nach:parts.slice(1).join(" ")};
}
function telHref(t){ return "tel:" + String(t||"").replace(/[^\d+]/g,""); }
function webHref(w){ w = String(w||"").trim(); return /^https?:\/\//i.test(w) ? w : "https://" + w; }
function displayName(l){ return l.name || l.firma || "Ohne Namen"; }
function normPhone(t){ return String(t||"").replace(/\D/g,"").replace(/^00/,"").replace(/^0/,"49"); }

function addHistory(l, text, sys=true){
  l.notes = l.notes || [];
  l.notes.unshift({id:uid(), ts:now(), text, sys});
}
function touch(l){ l.updated = now(); }

function setStage(l, stage, note=true){
  if(l.stage === stage) return;
  const from = l.stage;
  l.stage = stage;
  const col = db.leads.filter(x => x.stage === stage && x !== l);
  l.order = col.length ? Math.min(...col.map(x => x.order || 0)) - 1 : 0;
  if(note) addHistory(l, "Verschoben: " + STAGE_NAME[from] + " → " + STAGE_NAME[stage]);
  touch(l);
}

/* ================= E-Mail ================= */
function terminParts(v){
  if(!v) return {datum:"", uhrzeit:"", termin:""};
  const d = new Date(v);
  if(isNaN(d)) return {datum:v, uhrzeit:"", termin:v};
  const datum = d.toLocaleDateString("de-DE", {weekday:"long", day:"numeric", month:"long", year:"numeric"});
  const uhrzeit = d.toLocaleTimeString("de-DE", {hour:"2-digit", minute:"2-digit"});
  return {datum, uhrzeit, termin:datum + " um " + uhrzeit + " Uhr"};
}
function fillTemplate(tpl, l){
  const {vor, nach} = splitName(l.name);
  let gruss = "Guten Tag";
  if(l.anrede && nach) gruss = "Guten Tag " + l.anrede + " " + nach;
  else if(!l.anrede && vor && nach) gruss = "Guten Tag " + vor + " " + nach;
  const map = {
    begruessung:gruss, vorname:vor, nachname:nach, name:l.name||"", firma:l.firma||"",
    ort:l.ort||"", absender:db.settings.sender||"", absender_telefon:db.settings.senderPhone||"",
    link:l.meetlink||"", video:db.settings.video||""
  };
  Object.assign(map, terminParts(l.termin));
  return String(tpl||"")
    .replace(/\{\{\s*(\w+)\s*\}\}/g, (m,k) => k in map ? map[k] : m)
    .replace(/[ \t]+\n/g,"\n").replace(/\n{3,}/g,"\n\n").trim();
}
function isAppleTouch(){
  const ua = navigator.userAgent;
  return /iPad|iPhone|iPod/.test(ua) || (/Macintosh/.test(ua) && navigator.maxTouchPoints > 1);
}
// Sperrvermerke aus importierten Spalten (z. B. Sterneintrag, Werbewiderspruch)
function warnings(l){
  const w = [];
  for(const [k, v] of Object.entries(l.extra || {})){
    if(!/^\s*ja\b/i.test(v || "")) continue;
    if(/werbesperre|sterneintrag|robinson/i.test(k)) w.push({type:"tel", text:"Keine Werbeanrufe (Sterneintrag)"});
    else if(/werbewiderspruch|widerspruch/i.test(k)) w.push({type:"all", text:"Werbewiderspruch im Impressum"});
  }
  return w;
}
function okToContact(l, how){
  const w = warnings(l).filter(x => x.type === "all" || x.type === how);
  if(!w.length) return true;
  return confirm(displayName(l) + ":\n" + w.map(x => "• " + x.text).join("\n") +
    "\n\n" + (how === "tel" ? "Trotzdem anrufen?" : "Trotzdem E-Mail vorbereiten?"));
}
function openMail(l){
  if(!l.email){ toast("Für diesen Lead ist keine E-Mail-Adresse hinterlegt."); return; }
  if(!okToContact(l, "mail")) return;
  openComposer(l);
}
function sendMail(l, tpl){
  const s = db.settings;
  const subject = fillTemplate(tpl.subject, l);
  const body = fillTemplate(tpl.body, l);
  const e = encodeURIComponent;
  let mode = s.mode;
  if(mode === "auto") mode = isAppleTouch() ? "app" : /Android/i.test(navigator.userAgent) ? "mailto" : "web";
  if(mode === "app"){
    location.href = "googlegmail:///co?to=" + e(l.email) + "&subject=" + e(subject) + "&body=" + e(body);
  }else if(mode === "mailto"){
    location.href = "mailto:" + e(l.email) + "?subject=" + e(subject) + "&body=" + e(body);
  }else{
    const url = "https://mail.google.com/mail/u/" + e(s.account||"0") + "/?view=cm&fs=1&tf=1&to=" + e(l.email) + "&su=" + e(subject) + "&body=" + e(body);
    const w = window.open(url, "_blank");
    if(w){ try{ w.opener = null; }catch(_){} }
    else location.href = url;
  }
  l.lastMail = now();
  addHistory(l, "E-Mail „" + tpl.name + "“ in Gmail vorbereitet: „" + subject + "“");
  touch(l); save(); render();
  if(openId === l.id) renderDetail();
}

/* ================= Board ================= */
const board = $("#board");
let query = "";

function matches(l){
  if(!query) return true;
  const hay = [l.name,l.firma,l.email,l.telefon,l.ort,l.quelle,l.website,...Object.values(l.extra||{}),...(l.notes||[]).map(n=>n.text)].join(" ").toLowerCase();
  return query.split(/\s+/).every(q => hay.includes(q));
}

function cardHtml(l){
  const lastNote = (l.notes||[]).find(n => !n.sys);
  const due = dueInfo(l);
  const meta = [];
  if(l.telefon) meta.push(`<span>${ICON.phone}${esc(l.telefon)}</span>`);
  if(l.attempts) meta.push(`<span>${ICON.retry}${l.attempts}× versucht</span>`);
  const firm = [l.name ? l.firma : "", l.ort].filter(Boolean).join(" · ");
  let mail = "";
  if(l.stage === "email"){
    mail = l.email
      ? `<button type="button" class="card-mail" data-act="mail">E-Mail schreiben ${ICON.arrow}</button>` +
        (l.lastMail ? `<div class="card-sent">Zuletzt vorbereitet ${esc(rel(l.lastMail))}</div>` : "")
      : `<button type="button" class="card-mail" disabled>Keine E-Mail hinterlegt</button>`;
  }
  return `<article class="card" data-id="${esc(l.id)}">
    <div class="card-top"><span class="card-name">${esc(displayName(l))}</span><span class="card-age">${esc(rel(l.updated||l.created))}</span></div>
    ${firm ? `<div class="card-firm">${esc(firm)}</div>` : ""}
    ${meta.length ? `<div class="card-meta">${meta.join("")}</div>` : ""}
    ${due || warnings(l).length ? `<div class="card-badges">${due ? `<span class="badge ${due.cls}">${esc(due.text)}</span>` : ""}${warnings(l).map(w => `<span class="badge warm">${esc(w.text)}</span>`).join("")}</div>` : ""}
    ${lastNote ? `<p class="card-note">${esc(lastNote.text)}</p>` : ""}
    ${mail}
  </article>`;
}

function render(){
  const scrolls = {};
  $$(".col", board).forEach(c => scrolls[c.dataset.stage] = $(".col-list", c).scrollTop);
  const boardScroll = board.scrollLeft;

  board.innerHTML = STAGES.map(s => {
    const leads = db.leads.filter(l => l.stage === s.id && matches(l)).sort((a,b) => (a.order||0) - (b.order||0));
    return `<section class="col" data-stage="${s.id}">
      <header class="col-head">
        <div><span class="label">${s.no} / ${esc(STAGE_NAME[s.id])}</span>
        <h2>${esc(s.title)}${s.it ? " <i>" + esc(s.it) + "</i>" : ""}</h2></div>
        <span class="col-count">${leads.length}</span>
      </header>
      <div class="col-list">${leads.map(cardHtml).join("") || `<div class="col-empty">${query ? "Keine Treffer" : "Leads hierher ziehen"}</div>`}</div>
    </section>`;
  }).join("");

  $$(".col", board).forEach(c => { const v = scrolls[c.dataset.stage]; if(v) $(".col-list", c).scrollTop = v; });
  board.scrollLeft = boardScroll;
  renderStats();
}

function renderStats(){
  const L = db.leads;
  const open = L.filter(l => l.stage !== "closed").length;
  const termine = L.filter(l => l.stage === "termin").length;
  const closed = L.filter(l => l.stage === "closed").length;
  const t = todayStr();
  const due = L.filter(l => l.wiedervorlage && l.wiedervorlage <= t && l.stage !== "closed").length;
  $("#stats").innerHTML =
    `<span><b>${open}</b> offen</span><span><b>${termine}</b> Ersttermine</span><span><b>${closed}</b> geclosed</span>` +
    (due ? `<span class="due"><b>${due}</b> Wiedervorlage fällig</span>` : "");
}

if(SERVER && window.RW_VERSION) $(".brand .label").textContent = "Leads · V " + window.RW_VERSION;
$("#search").addEventListener("input", e => { query = e.target.value.trim().toLowerCase(); render(); });

/* ================= Ziehen & Ablegen (Maus + Touch) ================= */
let press = null;   // gedrückt, aber noch nicht gezogen
let drag = null;    // aktives Ziehen
const HOLD_MS = 230, MOVE_TOL = 8;

board.addEventListener("pointerdown", e => {
  const card = e.target.closest(".card");
  if(!card || e.target.closest("button,a,input")) return;
  if(e.pointerType === "mouse" && e.button !== 0) return;
  press = {id:card.dataset.id, card, x0:e.clientX, y0:e.clientY, x:e.clientX, y:e.clientY, type:e.pointerType, timer:null};
  if(e.pointerType !== "mouse"){
    card.classList.add("is-pressing");
    press.timer = setTimeout(() => { if(press) startDrag(); }, HOLD_MS);
  }
});

document.addEventListener("pointermove", e => {
  if(drag){ drag.x = e.clientX; drag.y = e.clientY; moveDrag(); return; }
  if(!press) return;
  press.x = e.clientX; press.y = e.clientY;
  const dist = Math.hypot(press.x - press.x0, press.y - press.y0);
  if(dist > MOVE_TOL){
    if(press.type === "mouse") startDrag();
    else cancelPress(); // Finger wischt: normal scrollen
  }
});

document.addEventListener("pointerup", e => {
  if(drag){ endDrag(); return; }
  if(!press) return;
  const p = press; cancelPress();
  if(Math.hypot(e.clientX - p.x0, e.clientY - p.y0) <= MOVE_TOL) openDetail(p.id);
});
document.addEventListener("pointercancel", () => { if(drag) endDrag(true); else cancelPress(); });
document.addEventListener("touchmove", e => { if(drag) e.preventDefault(); }, {passive:false});
board.addEventListener("contextmenu", e => { if(e.target.closest(".card")) e.preventDefault(); });

function cancelPress(){
  if(!press) return;
  clearTimeout(press.timer);
  press.card.classList.remove("is-pressing");
  press = null;
}

function startDrag(){
  const p = press; press = null;
  clearTimeout(p.timer);
  p.card.classList.remove("is-pressing");
  const r = p.card.getBoundingClientRect();
  const ghost = p.card.cloneNode(true);
  ghost.classList.add("ghost");
  ghost.style.width = r.width + "px";
  document.body.appendChild(ghost);
  p.card.classList.add("is-placeholder");
  document.body.classList.add("dragging");
  if(navigator.vibrate) try{ navigator.vibrate(12); }catch(_){}
  drag = {id:p.id, card:p.card, ghost, offX:p.x - r.left, offY:p.y - r.top, x:p.x, y:p.y,
          fromStage:byId(p.id).stage, raf:0};
  moveDrag();
  drag.raf = requestAnimationFrame(autoScroll);
}

function colAt(x, y){
  const el = document.elementFromPoint(x, y);
  return el ? el.closest(".col") : null;
}

function moveDrag(){
  const d = drag;
  d.ghost.style.left = (d.x - d.offX) + "px";
  d.ghost.style.top  = (d.y - d.offY) + "px";
  const col = colAt(d.x, d.y);
  $$(".col.is-target").forEach(c => { if(c !== col) c.classList.remove("is-target"); });
  if(!col) return;
  col.classList.add("is-target");
  const list = $(".col-list", col);
  const cards = $$(".card", list).filter(c => c !== d.card);
  let before = null;
  for(const c of cards){
    const r = c.getBoundingClientRect();
    if(d.y < r.top + r.height/2){ before = c; break; }
  }
  if(before){ if(d.card.nextSibling !== before) list.insertBefore(d.card, before); }
  else if(list.lastElementChild !== d.card || d.card.parentNode !== list){
    const empty = $(".col-empty", list);
    list.appendChild(d.card);
    if(empty) list.appendChild(empty);
  }
}

function autoScroll(){
  if(!drag) return;
  const edge = 70, max = 16;
  const br = board.getBoundingClientRect();
  if(drag.x < br.left + edge) board.scrollLeft -= Math.ceil(max * (1 - (drag.x - br.left)/edge));
  else if(drag.x > br.right - edge) board.scrollLeft += Math.ceil(max * (1 - (br.right - drag.x)/edge));
  const col = colAt(drag.x, drag.y);
  if(col){
    const list = $(".col-list", col), lr = list.getBoundingClientRect();
    if(drag.y < lr.top + 50) list.scrollTop -= 10;
    else if(drag.y > lr.bottom - 50) list.scrollTop += 10;
  }
  moveDrag();
  drag.raf = requestAnimationFrame(autoScroll);
}

function endDrag(cancelled){
  const d = drag; drag = null;
  cancelAnimationFrame(d.raf);
  d.ghost.remove();
  document.body.classList.remove("dragging");
  $$(".col.is-target").forEach(c => c.classList.remove("is-target"));
  if(!cancelled){
    const col = d.card.closest(".col");
    const l = byId(d.id);
    if(col && l){
      const stage = col.dataset.stage;
      if(stage !== l.stage){
        addHistory(l, "Verschoben: " + STAGE_NAME[l.stage] + " → " + STAGE_NAME[stage]);
        l.stage = stage; touch(l);
      }
      if(query){
        // Bei aktiver Suche sind nicht alle Karten sichtbar: nur oben einsortieren
        if(stage !== d.fromStage){
          const others = db.leads.filter(x => x.stage === stage && x !== l);
          l.order = others.length ? Math.min(...others.map(x => x.order || 0)) - 1 : 0;
        }
      }else{
        // Reihenfolge aus der sichtbaren Spalte übernehmen
        $$(".card", $(".col-list", col)).forEach((c, i) => { const x = byId(c.dataset.id); if(x) x.order = i; });
      }
      save();
      if(stage !== d.fromStage) toast(esc(displayName(l)) + " → " + STAGE_NAME[stage]);
    }
  }
  render();
}

board.addEventListener("click", e => {
  const btn = e.target.closest("[data-act='mail']");
  if(!btn) return;
  e.stopPropagation();
  const l = byId(btn.closest(".card").dataset.id);
  if(l) openMail(l);
});

/* ================= Overlays ================= */
function openOverlay(el){ el.classList.add("open"); }
function closeOverlay(el){
  el.classList.remove("open");
  if(el.id === "detailOverlay"){ flushDetail(); openId = null; render(); }
}
$$(".overlay").forEach(o => {
  o.addEventListener("click", e => { if(e.target === o || e.target.closest("[data-close]")) closeOverlay(o); });
});
document.addEventListener("keydown", e => {
  if(e.key === "Escape"){ const o = $$(".overlay.open").pop(); if(o) closeOverlay(o); }
});

/* ================= Lead-Detail ================= */
let openId = null;
const FIELDS = [
  {k:"anrede",  label:"Anrede", type:"select", opts:["","Herr","Frau"]},
  {k:"name",    label:"Name", ph:"Vor- und Nachname"},
  {k:"firma",   label:"Firma"},
  {k:"telefon", label:"Telefon", type:"tel", act:"tel"},
  {k:"email",   label:"E-Mail", type:"email", act:"mail"},
  {k:"ort",     label:"Ort"},
  {k:"website", label:"Website", act:"web"},
  {k:"quelle",  label:"Quelle", ph:"z. B. Liste Oktober"},
  {k:"wiedervorlage", label:"Wiedervorlage", type:"date"},
  {k:"termin",  label:"Ersttermin", type:"datetime-local"},
  {k:"meetlink", label:"Meeting-Link", act:"meet", ph:"z. B. Google-Meet- oder Zoom-Link"}
];
const stageSel = $("#dStage");
stageSel.innerHTML = STAGES.map(s => `<option value="${s.id}">${esc(STAGE_NAME[s.id])}</option>`).join("");

function openDetail(id){
  openId = id;
  renderDetail(true);
  openOverlay($("#detailOverlay"));
}

function renderDetail(full){
  const l = byId(openId); if(!l) return;
  $("#dSince").textContent = "Lead seit " + fmtDate(l.created, false);
  $("#dName").textContent = displayName(l);
  $("#dFirm").textContent = l.name ? (l.firma || "") : "";
  stageSel.value = l.stage;

  if(full){
    $("#dFields").innerHTML = FIELDS.map(f => {
      const v = l[f.k] || "";
      const input = f.type === "select"
        ? `<select data-k="${f.k}">${f.opts.map(o => `<option value="${o}" ${o===v?"selected":""}>${o||"–"}</option>`).join("")}</select>`
        : `<input data-k="${f.k}" type="${f.type||"text"}" value="${esc(v)}" placeholder="${esc(f.ph||"–")}" ${f.type==="email"||f.act==="web"||f.act==="meet"?'autocapitalize="off" autocorrect="off"':""}>`;
      let act = "";
      if(f.act === "tel") act = `<a class="fact" data-fact="tel" title="Anrufen">${ICON.phone}</a>`;
      if(f.act === "mail") act = `<button type="button" class="fact" data-fact="mail" title="E-Mail schreiben">${ICON.mail}</button>`;
      if(f.act === "web") act = `<a class="fact" data-fact="web" target="_blank" rel="noopener" title="Website öffnen">${ICON.web}</a>`;
      if(f.act === "meet") act = `<a class="fact" data-fact="meet" target="_blank" rel="noopener" title="Meeting öffnen">${ICON.web}</a>`;
      return `<label class="field"><span class="label">${esc(f.label)}</span>${input}${act}</label>`;
    }).join("");
    $("#dExtra").innerHTML = extraFieldsHtml(l);
    $("#dNote").value = "";
  }
  if(!full) ["termin", "meetlink"].forEach(k => {
    const i = $(`#dFields [data-k="${k}"]`);
    if(i && document.activeElement !== i && i.value !== (l[k] || "")) i.value = l[k] || "";
  });
  updateFieldActions(l);
  const w = warnings(l);
  $("#dWarn").classList.toggle("hidden", !w.length);
  $("#dWarn").innerHTML = w.map(x => "<b>Achtung:</b> " + esc(x.text) + (x.type === "tel" ? " – Werbeanrufe sind hier nicht erlaubt." : " – die Firma widerspricht Werbung.")).join("<br>");

  const q = [];
  q.push(`<button type="button" class="btn btn-line btn-sm" data-q="noreach">${ICON.retry} Nicht erreicht${l.attempts ? " · " + l.attempts + "×" : ""}</button>`);
  q.push(`<button type="button" class="btn btn-line btn-sm" data-q="mail" ${l.email ? "" : "disabled style='opacity:.45'"}>${ICON.mail} E-Mail schreiben</button>`);
  if(l.stage !== "termin" && l.stage !== "closed") q.push(`<button type="button" class="btn btn-line btn-sm" data-q="termin">${ICON.cal} Ersttermin gebucht</button>`);
  if(l.stage !== "closed") q.push(`<button type="button" class="btn btn-line btn-sm" data-q="closed">${ICON.check} Geclosed</button>`);
  $("#dQuick").innerHTML = q.join("");

  const notes = l.notes || [];
  $("#dTimeline").innerHTML = notes.length ? notes.map(n => `
    <li class="tl ${n.sys ? "sys" : ""}">
      <span class="tl-date">${esc(fmtDate(n.ts))}</span>
      <div class="tl-text">${esc(n.text)}</div>
      <button type="button" class="tl-del" data-del="${esc(n.id)}" title="Eintrag entfernen">${ICON.x}</button>
    </li>`).join("") : `<li class="tl-empty">Noch keine Notizen. Der erste Eintrag steht oben.</li>`;
}

function extraFieldsHtml(l){
  const fields = db.settings.fields || [];
  const rows = fields.map(k => {
    const v = (l.extra || {})[k] || "";
    const long = v.length > 60 || v.includes("\n");
    const input = long
      ? `<textarea data-x="${esc(k)}" rows="${Math.min(6, Math.ceil(v.length / 38) + 1)}" placeholder="–">${esc(v)}</textarea>`
      : `<input data-x="${esc(k)}" type="text" value="${esc(v)}" placeholder="–">`;
    return `<label class="field"><span class="label">${esc(k)}</span>${input}<button type="button" class="fact fact-sm" data-xdel="${esc(k)}" title="Feld „${esc(k)}“ entfernen">${ICON.x}</button></label>`;
  }).join("");
  return `<div class="extra-head"><span class="label">Angaben zum Lead</span><button type="button" class="add-field" data-xadd>+ Feld hinzufügen</button></div>` +
    (fields.length ? `<div class="extra-grid">${rows}</div>` : `<p class="extra-empty">Zusätzliche Spalten aus Ihren Listen – etwa Objektart oder Anzahl Objekte – erscheinen hier automatisch.</p>`);
}
function setExtra(l, k, v){
  l.extra = l.extra || {};
  if(v) l.extra[k] = v; else delete l.extra[k];
}

function updateFieldActions(l){
  const tel = $("[data-fact='tel']"), mail = $("[data-fact='mail']"), web = $("[data-fact='web']");
  if(tel){ tel.href = l.telefon ? telHref(l.telefon) : "#"; tel.classList.toggle("off", !l.telefon); }
  if(mail) mail.classList.toggle("off", !l.email);
  if(web){ web.href = l.website ? webHref(l.website) : "#"; web.classList.toggle("off", !l.website); }
  const meet = $("[data-fact='meet']");
  if(meet){ meet.href = l.meetlink ? webHref(l.meetlink) : "#"; meet.classList.toggle("off", !l.meetlink); }
}

let saveTimer = null;
["#dFields", "#dExtra"].forEach(sel => $(sel).addEventListener("input", e => {
  const k = e.target.dataset.k, x = e.target.dataset.x; if(!k && !x) return;
  const l = byId(openId); if(!l) return;
  if(x) setExtra(l, x, e.target.value.trim());
  else l[k] = e.target.value.trim();
  touch(l);
  $("#dName").textContent = displayName(l);
  $("#dFirm").textContent = l.name ? (l.firma || "") : "";
  updateFieldActions(l);
  $("#dSaved").textContent = "Wird gespeichert …";
  clearTimeout(saveTimer);
  saveTimer = setTimeout(() => { save(); $("#dSaved").textContent = "Gespeichert"; }, 350);
}));
["#dFields", "#dExtra"].forEach(sel => $(sel).addEventListener("change", e => { if(e.target.dataset.k || e.target.dataset.x){ save(); $("#dSaved").textContent = "Gespeichert"; } }));
["#dFields", "#dExtra"].forEach(sel => $(sel).addEventListener("click", e => {
  const b = e.target.closest("[data-fact='mail']");
  if(b){ e.preventDefault(); const l = byId(openId); if(l) openMail(l); return; }
  const t = e.target.closest("[data-fact='tel']");
  if(t){ const l = byId(openId); if(l && !okToContact(l, "tel")) e.preventDefault(); return; }
  const del = e.target.closest("[data-xdel]");
  if(del){
    e.preventDefault();
    const k = del.dataset.xdel;
    const used = db.leads.filter(x => (x.extra || {})[k]).length;
    if(!confirm("Feld „" + k + "“ bei allen Leads entfernen?" + (used ? "\n\nEs ist bei " + used + " Lead" + (used > 1 ? "s" : "") + " ausgefüllt – diese Angaben gehen verloren." : ""))) return;
    flushDetail();
    db.settings.fields = db.settings.fields.filter(f => f !== k);
    db.leads.forEach(x => { if(x.extra && k in x.extra){ delete x.extra[k]; touch(x); } });
    save(); renderDetail(true); render();
    return;
  }
  if(e.target.closest("[data-xadd]")){
    e.preventDefault();
    const name = (prompt("Name des neuen Feldes (z. B. „Objektart“ oder „Anzahl Objekte“):") || "").trim();
    if(!name) return;
    if(FIELDS.some(f => f.label.toLowerCase() === name.toLowerCase()) || db.settings.fields.some(f => f.toLowerCase() === name.toLowerCase())){
      toast("Dieses Feld gibt es schon."); return;
    }
    flushDetail();
    db.settings.fields.push(name); save(); renderDetail(true);
    const inp = $$("#dExtra [data-x]").find(i => i.dataset.x === name); if(inp) inp.focus();
  }
}));
function flushDetail(){ if(saveTimer){ clearTimeout(saveTimer); saveTimer = null; save(); } }

stageSel.addEventListener("change", () => {
  const l = byId(openId); if(!l) return;
  setStage(l, stageSel.value); save(); renderDetail(); render();
});

function addNote(){
  const ta = $("#dNote"); const text = ta.value.trim();
  const l = byId(openId); if(!text || !l) return;
  addHistory(l, text, false); touch(l); save();
  ta.value = ""; renderDetail(); render();
}
$("#dAddNote").addEventListener("click", addNote);
$("#dNote").addEventListener("keydown", e => { if(e.key === "Enter" && (e.metaKey || e.ctrlKey)){ e.preventDefault(); addNote(); } });

$("#dTimeline").addEventListener("click", e => {
  const b = e.target.closest("[data-del]"); if(!b) return;
  const l = byId(openId); if(!l) return;
  const n = (l.notes||[]).find(x => x.id === b.dataset.del);
  if(n && !n.sys && !confirm("Diese Notiz löschen?")) return;
  l.notes = (l.notes||[]).filter(n => n.id !== b.dataset.del);
  forget(b.dataset.del);
  save(); renderDetail(); render();
});

$("#dQuick").addEventListener("click", e => {
  const b = e.target.closest("[data-q]"); if(!b) return;
  const l = byId(openId); if(!l) return;
  const q = b.dataset.q;
  if(q === "mail"){ openMail(l); return; }
  if(q === "noreach"){
    l.attempts = (l.attempts||0) + 1;
    addHistory(l, "Anrufversuch " + l.attempts + " – nicht erreicht");
    if(l.stage === "neu") setStage(l, "nicht_erreicht");
    touch(l);
  }
  if(q === "termin") setStage(l, "termin");
  if(q === "closed") setStage(l, "closed");
  save(); renderDetail(); render();
});

let lastDeleted = null;
$("#dDelete").addEventListener("click", () => {
  const l = byId(openId); if(!l) return;
  if(!confirm("„" + displayName(l) + "“ wirklich löschen?")) return;
  lastDeleted = {lead:l, index:db.leads.indexOf(l)};
  db.leads = db.leads.filter(x => x !== l);
  forget(l.id);
  save();
  closeOverlay($("#detailOverlay"));
  toast("Lead gelöscht", "Rückgängig", () => {
    if(!lastDeleted) return;
    db.leads.splice(lastDeleted.index, 0, lastDeleted.lead);
    db.deleted = (db.deleted || []).filter(x => x !== lastDeleted.lead.id);
    lastDeleted = null; save(); render();
  });
});

/* ================= Leads einfügen ================= */
const KEYMAP = [
  ["anrede", /^(anrede|salutation)$/],
  ["name", /^(name|ansprechpartner(in)?|kontakt(person)?|person|vor-? ?und nachname|vollst.*name|contact)$/],
  ["vorname", /^(vorname|first ?name)$/],
  ["nachname", /^(nachname|last ?name|surname)$/],
  ["firma", /^(firma|unternehmen|company|büro|buero|maklerbüro|maklerbuero|agentur|makler|firmenname)$/],
  ["telefon", /^(telefon|tel\.?|telefonnummer|phone|handy|mobil|mobile|nummer|tel\.? ?nr\.?)$/],
  ["email", /^(e-?mail|mail|email-?adresse|e-mail-adresse)$/],
  ["ort", /^(ort|stadt|city|standort|plz ?\/? ?ort|region)$/],
  ["website", /^(website|webseite|web|homepage|url|internet)$/],
  ["quelle", /^(quelle|source|herkunft)$/],
  ["notiz", /^(notiz|notizen|bemerkung|bemerkungen|kommentar|note|notes)$/]
];
const RX_MAIL = /[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/i;
const RX_PHONE = /^\+?[\d][\d\s\/().-]{5,}\d$/;
const RX_WEB = /^(https?:\/\/|www\.)\S+$|^[a-z0-9-]+(\.[a-z0-9-]+)*\.(de|ch|at|com|net|org|eu|immobilien|info|io|biz)(\/\S*)?$/i;
const RX_FIRM = /\b(gmbh|ag|kg|ohg|ug|e\.?\s?k\.?|immobilien|makler|realty|real estate|estate|partner|wohnbau|haus|verwaltung|properties|group|gruppe|&)\b/i;

function keyOf(h){
  const t = String(h||"").toLowerCase().replace(/[:*]/g,"").trim();
  for(const [k, rx] of KEYMAP) if(rx.test(t)) return k;
  return null;
}
function cleanLabel(h){
  h = String(h || "").replace(/^"|"$/g, "").replace(/\s+/g, " ").replace(/:$/, "").trim();
  return h ? h[0].toUpperCase() + h.slice(1) : h;
}
function finalize(o){
  if(!o.name && (o.vorname || o.nachname)) o.name = [o.vorname, o.nachname].filter(Boolean).join(" ");
  delete o.vorname; delete o.nachname;
  if(o.email){ const m = String(o.email).match(RX_MAIL); o.email = m ? m[0].toLowerCase() : ""; }
  if(o.anrede){ o.anrede = /frau/i.test(o.anrede) ? "Frau" : /herr/i.test(o.anrede) ? "Herr" : ""; }
  // „Herr Max Muster“ im Namen erkennen
  if(o.name){
    const m = o.name.match(/^(Herr|Frau)\s+(.+)$/i);
    if(m){ o.anrede = o.anrede || (m[1][0].toUpperCase() + m[1].slice(1).toLowerCase()); o.name = m[2]; }
  }
  for(const k in o) if(typeof o[k] === "string") o[k] = o[k].trim();
  return o;
}
function classifyCells(cells){
  const o = {}, rest = [];
  for(let c of cells){
    c = c.trim().replace(/^"|"$/g,"").trim();
    if(!c) continue;
    const m = c.match(RX_MAIL);
    if(m && !o.email && c.replace(m[0],"").replace(/[<>()\s,;:]|mailto/gi,"") === ""){ o.email = m[0]; continue; }
    if(!o.telefon && RX_PHONE.test(c) && (c.replace(/\D/g,"").length >= 6)){ o.telefon = c; continue; }
    if(!o.website && RX_WEB.test(c)){ o.website = c; continue; }
    if(!o.anrede && /^(herr|frau)$/i.test(c)){ o.anrede = c; continue; }
    rest.push(c);
  }
  for(const c of rest){
    if(!o.firma && RX_FIRM.test(c)) { o.firma = c; continue; }
    if(!o.name) { o.name = c; continue; }
    if(!o.firma) { o.firma = c; continue; }
    if(!o.ort && c.length < 40 && !/\d{6,}/.test(c)) { o.ort = c; continue; }
    o.notiz = (o.notiz ? o.notiz + " · " : "") + c;
  }
  return o;
}
function splitLine(line, sep){
  if(sep === "\t" || sep === ";" || sep === "|") return line.split(sep);
  // Komma mit Anführungszeichen
  const out = []; let cur = "", q = false;
  for(const ch of line){
    if(ch === '"'){ q = !q; continue; }
    if(ch === "," && !q){ out.push(cur); cur = ""; continue; }
    cur += ch;
  }
  out.push(cur);
  return out;
}
const isKv = l => /^\s*[A-Za-zÄÖÜäöüß .\-\/]{2,30}\s*:\s*\S/.test(l) && !!keyOf(l.split(":")[0]);
function sepOf(s){
  return s.includes("\t") ? "\t" : s.includes(";") ? ";" : s.includes("|") ? "|" : s.includes(",") ? "," : null;
}
function parseBlock(lines){
  const out = []; let cur = {};
  const push = () => { if(Object.keys(cur).length){ out.push(finalize(cur)); cur = {}; } };
  for(const line of lines){
    const idx = line.indexOf(":");
    const k = idx > 0 && isKv(line) ? keyOf(line.slice(0, idx)) : null;
    const gm = !k && line.match(/^([A-Za-zÄÖÜäöüß][A-Za-zÄÖÜäöüß0-9 .\-\/()#&]{1,39})\s*:\s*(.+)$/);
    if(k){
      const v = line.slice(idx + 1).trim();
      if(cur[k] && k !== "notiz") push();
      cur[k] = k === "notiz" && cur.notiz ? cur.notiz + " " + v : v;
    }else if(gm && !/^https?$/i.test(gm[1].trim())){
      cur.extra = cur.extra || {};
      cur.extra[cleanLabel(gm[1])] = gm[2].trim();
    }else{
      // Zeile ohne Schlüssel: E-Mail / Telefon erkennen, sonst Notiz
      const c = classifyCells([line]);
      if(c.email && !cur.email) cur.email = c.email;
      else if(c.telefon && !cur.telefon) cur.telefon = c.telefon;
      else if(c.website && !cur.website) cur.website = c.website;
      else if(!Object.keys(cur).length) Object.assign(cur, c);
      else cur.notiz = (cur.notiz ? cur.notiz + " " : "") + line;
    }
  }
  push();
  return out;
}
function parseFree(r){
  // Freitext-Zeile: E-Mail & Telefon herausziehen, Rest an „ - “ trennen
  let rest = r;
  const o = {};
  const m = rest.match(RX_MAIL); if(m){ o.email = m[0]; rest = rest.replace(m[0], " "); }
  const p = rest.match(/\+?\d[\d\s\/().-]{5,}\d/); if(p && p[0].replace(/\D/g,"").length >= 6){ o.telefon = p[0].trim(); rest = rest.replace(p[0], " "); }
  let parts = rest.split(/\s+[-–—]\s+|\s{2,}/).map(s => s.trim()).filter(s => s && !/^[-–—]+$/.test(s));
  // „Lisa Sommer Sommer Immobilien“ → Name + Firma
  if(parts.length === 1 && RX_FIRM.test(parts[0])){
    const w = parts[0].split(/\s+/);
    if(w.length >= 3 && /^[A-ZÄÖÜ]/.test(w[0]) && /^[A-ZÄÖÜ]/.test(w[1]) && !RX_FIRM.test(w[0] + " " + w[1]))
      parts = [w.slice(0,2).join(" "), w.slice(2).join(" ")];
  }
  const c = classifyCells(parts);
  return Object.assign(c, {email:o.email || c.email, telefon:o.telefon || c.telefon});
}
function parseRows(rows, state){
  const out = [];
  let {header, headerRaw, hsep} = state;
  rows.forEach((r, i) => {
    const sep = sepOf(r);
    if(sep){
      const raw = splitLine(r, sep).map(c => c.trim());
      const keys = raw.map(keyOf);
      if(keys.filter(Boolean).length >= 2 && !RX_MAIL.test(r)){
        header = keys; headerRaw = raw; hsep = sep;
        Object.assign(state, {header, headerRaw, hsep});
        // Zusatzfelder in Spaltenreihenfolge (auch Spalten, die eine zweite Telefonnummer o. Ä. enthalten)
        const seen = new Set();
        raw.forEach((h, j) => {
          const k = keys[j];
          if(h && (!k || seen.has(k))) lastFieldOrder.push(cleanLabel(h));
          if(k) seen.add(k);
        });
        return;
      }
    }
    if(header && sep === hsep){
      const o = {}, extra = [];
      splitLine(r, sep).forEach((c, j) => {
        c = c.trim(); if(!c) return;
        const k = header[j];
        if(k && (!o[k] || k === "notiz")) o[k] = o[k] ? o[k] + " · " + c : c;
        else if(headerRaw[j]) { o.extra = o.extra || {}; o.extra[cleanLabel(headerRaw[j])] = c; }
        else extra.push(c);
      });
      if(extra.length) o.notiz = [o.notiz, ...extra].filter(Boolean).join(" · ");
      out.push(finalize(o));
    }else if(sep){
      out.push(finalize(classifyCells(splitLine(r, sep))));
    }else{
      out.push(finalize(parseFree(r)));
    }
  });
  return out;
}
let lastFieldOrder = [];
// CSV mit Anführungszeichen (Trennzeichen oder Zeilenumbrüche in Zellen) sauber in Tab-Zeilen umwandeln
function csvToTsv(text, d){
  const rows = []; let row = [], cell = "", q = false;
  for(let i = 0; i < text.length; i++){
    const ch = text[i];
    if(q){
      if(ch === '"'){ if(text[i+1] === '"'){ cell += '"'; i++; } else q = false; }
      else cell += ch;
    }else if(ch === '"' && cell.trim() === "") { q = true; cell = ""; }
    else if(ch === d){ row.push(cell); cell = ""; }
    else if(ch === "\n"){ row.push(cell); rows.push(row); row = []; cell = ""; }
    else cell += ch;
  }
  row.push(cell); rows.push(row);
  return rows.map(r => r.map(c => c.replace(/[\t\n]+/g, " ").trim()).join("\t")).join("\n");
}
function parseLeads(text){
  lastFieldOrder = [];
  text = String(text||"").replace(/\r+\n|\r/g,"\n").replace(/ /g," ");
  if(!text.trim()) return [];
  const firstLine = text.slice(0, text.indexOf("\n") >= 0 ? text.indexOf("\n") : undefined);
  if(!firstLine.includes("\t") && text.includes('"')){
    const d = firstLine.split(";").length >= firstLine.split(",").length ? ";" : ",";
    if(firstLine.split(d).length >= 3) text = csvToTsv(text, d);
  }
  // In Abschnitte zerlegen (Leerzeilen). Abschnitte mit „Name: …“-Zeilen sind ein Block-Lead,
  // alle anderen werden zeilenweise gelesen.
  const out = [];
  // Nur Leerzeichen am Rand entfernen – führende Tabs stehen für leere Zellen
  const segments = text.split(/\n[ \u00a0]*\n/).map(s => s.split("\n").map(l => l.replace(/^[ \u00a0]+|[ \u00a0]+$/g, "")).filter(l => l.replace(/\t/g, "").trim())).filter(s => s.length);
  const state = {header:null, headerRaw:null, hsep:null};  // Kopfzeile gilt auch nach Leerzeilen weiter
  for(const seg of segments){
    const kv = seg.filter(isKv).length;
    if(kv >= 2 && kv >= seg.length * 0.5) out.push(...parseBlock(seg.map(l => l.trim())));
    else out.push(...parseRows(seg, state));
  }
  return out.filter(o => o.name || o.firma || o.email || o.telefon);
}
function findDup(o){
  const ph = o.telefon ? normPhone(o.telefon) : "";
  return db.leads.find(l =>
    (o.email && l.email && l.email.toLowerCase() === o.email.toLowerCase()) ||
    (ph && ph.length >= 7 && l.telefon && normPhone(l.telefon) === ph)
  );
}
function newLead(o, source){
  const t = now();
  const l = {
    id:uid(), created:t, updated:t, stage:"neu", order:0, attempts:0,
    anrede:o.anrede||"", name:o.name||"", firma:o.firma||"", telefon:o.telefon||"", email:o.email||"",
    ort:o.ort||"", website:o.website||"", quelle:o.quelle || source || "", wiedervorlage:"", notes:[],
    extra:Object.assign({}, o.extra || {})
  };
  if(o.notiz) l.notes.push({id:uid(), ts:t, text:o.notiz, sys:false});
  return l;
}

let parsed = [];
let importTab = "paste";
const pasteArea = $("#pasteArea");
function renderPreview(){
  parsed = parseLeads(pasteArea.value).map(o => ({o, dup:findDup(o), on:true}));
  // Dubletten innerhalb der Liste
  const seen = new Set();
  parsed.forEach(p => {
    const k = (p.o.email||"").toLowerCase() || normPhone(p.o.telefon);
    if(k && seen.has(k)) p.dupList = true;
    if(k) seen.add(k);
    p.noContact = !(p.o.telefon || p.o.email || p.o.website);
    if(p.dup || p.dupList || p.noContact) p.on = false;
  });
  const wrap = $("#previewWrap");
  if(!parsed.length){
    wrap.innerHTML = pasteArea.value.trim() ? `<p class="hint">Noch kein Lead erkannt – bitte pro Zeile mindestens Name, Telefon oder E-Mail.</p>` : "";
  }else{
    wrap.innerHTML = `<table class="preview"><thead><tr>
      <th style="width:28px"></th><th>Name</th><th>Firma</th><th>Telefon</th><th>E-Mail</th><th class="opt">Ort</th><th class="opt">Notiz &amp; Felder</th></tr></thead><tbody>
      ${parsed.map((p,i) => `<tr class="${p.dup||p.dupList||p.noContact ? "dup" : ""}">
        <td><input type="checkbox" data-i="${i}" ${p.on ? "checked" : ""}></td>
        <td>${esc((p.o.anrede ? p.o.anrede + " " : "") + (p.o.name||"–"))}${p.dup ? `<span class="dup-tag">schon vorhanden: ${esc(displayName(p.dup))}</span>` : p.dupList ? `<span class="dup-tag">doppelt in der Liste</span>` : p.noContact ? `<span class="dup-tag">ohne Telefon/E-Mail – abgewählt</span>` : ""}</td>
        <td>${esc(p.o.firma||"–")}</td><td>${esc(p.o.telefon||"–")}</td><td>${esc(p.o.email||"–")}</td>
        <td class="opt">${esc(p.o.ort||"–")}</td><td class="opt">${esc(p.o.notiz||"")}${p.o.extra && Object.keys(p.o.extra).length ? `<span class="dup-tag" style="color:var(--sage)">+ ${Object.keys(p.o.extra).map(esc).join(", ")}</span>` : ""}</td></tr>`).join("")}
      </tbody></table>`;
  }
  updateImportBtn();
}
pasteArea.addEventListener("input", renderPreview);

/* ---- Dateien lesen: .xlsx / .docx (ZIP mit XML), .csv / .txt ---- */
async function unzip(buf){
  const dv = new DataView(buf), u8 = new Uint8Array(buf), files = {};
  let eocd = -1;
  for(let i = u8.length - 22; i >= Math.max(0, u8.length - 66000); i--) if(dv.getUint32(i, true) === 0x06054b50){ eocd = i; break; }
  if(eocd < 0) throw new Error("Keine gültige Office-Datei");
  let p = dv.getUint32(eocd + 16, true);
  const n = dv.getUint16(eocd + 10, true);
  const dec = new TextDecoder();
  for(let i = 0; i < n; i++){
    if(dv.getUint32(p, true) !== 0x02014b50) break;
    const method = dv.getUint16(p + 10, true), csize = dv.getUint32(p + 20, true);
    const nlen = dv.getUint16(p + 28, true), xlen = dv.getUint16(p + 30, true), clen = dv.getUint16(p + 32, true);
    const off = dv.getUint32(p + 42, true);
    const name = dec.decode(u8.subarray(p + 46, p + 46 + nlen));
    files[name] = {method, csize, off};
    p += 46 + nlen + xlen + clen;
  }
  return async name => {
    const f = files[name]; if(!f) return null;
    const start = f.off + 30 + dv.getUint16(f.off + 26, true) + dv.getUint16(f.off + 28, true);
    const data = u8.subarray(start, start + f.csize);
    if(f.method === 0) return dec.decode(data);
    if(typeof DecompressionStream === "undefined") throw new Error("Dieser Browser kann keine Office-Dateien entpacken – bitte Inhalt kopieren und einfügen.");
    const stream = new Blob([data]).stream().pipeThrough(new DecompressionStream("deflate-raw"));
    return await new Response(stream).text();
  };
}
const xml = t => new DOMParser().parseFromString(t, "application/xml");
const byTag = (node, tag) => Array.from(node.getElementsByTagName("*")).filter(e => e.localName === tag);
function colIndex(ref){
  const m = /^([A-Z]+)/.exec(ref || ""); if(!m) return -1;
  let n = 0; for(const ch of m[1]) n = n * 26 + ch.charCodeAt(0) - 64; return n - 1;
}
function cellText(v){ return String(v ?? "").replace(/[\t\r\n]+/g, " ").trim(); }
async function xlsxToText(buf){
  const get = await unzip(buf);
  const shared = [];
  const ss = await get("xl/sharedStrings.xml");
  if(ss) byTag(xml(ss), "si").forEach(si => shared.push(byTag(si, "t").map(t => t.textContent).join("")));
  // erstes Tabellenblatt laut Arbeitsmappe
  let sheet = "xl/worksheets/sheet1.xml";
  try{
    const wb = xml(await get("xl/workbook.xml")), rels = xml(await get("xl/_rels/workbook.xml.rels"));
    const first = byTag(wb, "sheet")[0];
    const rid = first && (first.getAttribute("r:id") || first.getAttributeNS("http://schemas.openxmlformats.org/officeDocument/2006/relationships", "id"));
    const rel = byTag(rels, "Relationship").find(r => r.getAttribute("Id") === rid);
    if(rel){ const t = rel.getAttribute("Target").replace(/^\/?(xl\/)?/, ""); sheet = "xl/" + t; }
  }catch(_){}
  const sx = await get(sheet);
  if(!sx) throw new Error("Tabellenblatt nicht gefunden");
  const lines = [];
  byTag(xml(sx), "row").forEach(row => {
    const cells = [];
    byTag(row, "c").forEach((c, i) => {
      const idx = c.getAttribute("r") ? colIndex(c.getAttribute("r")) : i;
      const t = c.getAttribute("t");
      const vEl = byTag(c, "v")[0];
      let v = "";
      if(t === "s") v = shared[+(vEl ? vEl.textContent : -1)] ?? "";
      else if(t === "inlineStr") v = byTag(c, "t").map(x => x.textContent).join("");
      else v = vEl ? vEl.textContent : "";
      cells[idx] = cellText(v);
    });
    const line = Array.from(cells, x => x || "").join("\t");
    if(line.replace(/\t/g, "").trim()) lines.push(line);
  });
  return lines.join("\n");
}
async function docxToText(buf){
  const get = await unzip(buf);
  const doc = xml(await get("word/document.xml"));
  const body = byTag(doc, "body")[0];
  const out = [];
  const para = p => byTag(p, "t").map(t => t.textContent).join("").trim();
  for(const node of Array.from(body ? body.children : [])){
    if(node.localName === "tbl"){
      out.push("");
      byTag(node, "tr").forEach(tr => {
        const cells = Array.from(tr.children).filter(c => c.localName === "tc").map(tc => cellText(byTag(tc, "p").map(para).filter(Boolean).join(" ")));
        if(cells.join("").trim()) out.push(cells.join("\t"));
      });
      out.push("");
    }else if(node.localName === "p"){
      out.push(para(node));
    }
  }
  return out.join("\n").replace(/\n{3,}/g, "\n\n").trim();
}
$("#leadFile").addEventListener("change", async e => {
  const f = e.target.files[0]; e.target.value = ""; if(!f) return;
  const hint = $("#leadFileHint");
  hint.textContent = "Lese „" + f.name + "“ …";
  try{
    const name = f.name.toLowerCase();
    let text;
    if(name.endsWith(".xlsx")) text = await xlsxToText(await f.arrayBuffer());
    else if(name.endsWith(".docx")) text = await docxToText(await f.arrayBuffer());
    else if(name.endsWith(".xls") || name.endsWith(".doc") || name.endsWith(".pdf") || name.endsWith(".numbers") || name.endsWith(".pages"))
      throw new Error("Dieses Format geht leider nicht. Bitte als .xlsx, .docx oder .csv speichern – oder den Inhalt kopieren und oben einfügen.");
    else{
      const buf = await f.arrayBuffer();
      try{ text = new TextDecoder("utf-8", {fatal:true}).decode(buf); }
      catch(_){ text = new TextDecoder("windows-1252").decode(buf); }
      text = text.replace(/^\ufeff/, "");
    }
    pasteArea.value = text;
    renderPreview();
    hint.textContent = "„" + f.name + "“ geladen – " + parsed.length + " Lead" + (parsed.length === 1 ? "" : "s") + " erkannt. Bitte unten prüfen.";
  }catch(err){
    hint.textContent = err.message || "Die Datei konnte nicht gelesen werden.";
  }
});
$("#previewWrap").addEventListener("change", e => {
  const i = e.target.dataset.i; if(i == null) return;
  parsed[+i].on = e.target.checked; updateImportBtn();
});
function singleData(){
  const o = {};
  $$("#singleForm [name]").forEach(el => o[el.name] = el.value.trim());
  return o;
}
$("#singleForm").addEventListener("input", updateImportBtn);
function updateImportBtn(){
  const btn = $("#importGo");
  if(importTab === "paste"){
    const n = parsed.filter(p => p.on).length;
    btn.disabled = !n;
    btn.textContent = n === 1 ? "1 Lead übernehmen" : n ? n + " Leads übernehmen" : "Leads übernehmen";
    const dups = parsed.filter(p => p.dup || p.dupList).length, nc = parsed.filter(p => p.noContact && !p.dup && !p.dupList).length;
    const parts = [];
    if(dups) parts.push(dups + " mögliche Dublette" + (dups>1?"n":""));
    if(nc) parts.push(nc + " Zeile" + (nc>1?"n":"") + " ohne Kontaktdaten");
    $("#importHint").textContent = parts.length ? parts.join(" und ") + " abgewählt – bei Bedarf anhaken." : "Neue Leads landen oben in „Neuer Lead“.";
  }else{
    const o = singleData();
    btn.disabled = !(o.name || o.firma);
    btn.textContent = "Lead anlegen";
    const d = (o.email || o.telefon) ? findDup(o) : null;
    $("#importHint").textContent = d ? "Achtung: ähnlicher Lead vorhanden – " + displayName(d) : "Landet oben in „Neuer Lead“.";
  }
}
$$(".tab").forEach(t => t.addEventListener("click", () => {
  importTab = t.dataset.tab;
  $$(".tab").forEach(x => x.classList.toggle("on", x === t));
  $$("[data-pane]").forEach(p => p.classList.toggle("hidden", p.dataset.pane !== importTab));
  updateImportBtn();
  setTimeout(() => (importTab === "paste" ? pasteArea : $("#singleForm [name=name]")).focus(), 30);
}));
$("#openImport").addEventListener("click", () => {
  openOverlay($("#importOverlay"));
  updateImportBtn();
  setTimeout(() => (importTab === "paste" ? pasteArea : $("#singleForm [name=name]")).focus(), 60);
});
$("#importGo").addEventListener("click", () => {
  let added = [];
  if(importTab === "paste"){
    const src = $("#pasteSource").value.trim();
    added = parsed.filter(p => p.on).map(p => newLead(p.o, src));
  }else{
    const o = singleData();
    if(!(o.name || o.firma)) return;
    added = [newLead(o, o.quelle)];
  }
  if(!added.length) return;
  // oben in „Neuer Lead“ einsortieren
  const col = db.leads.filter(l => l.stage === "neu");
  let top = col.length ? Math.min(...col.map(l => l.order||0)) : 0;
  for(let i = added.length - 1; i >= 0; i--) added[i].order = --top;
  db.leads.push(...added);
  const used = new Set(added.flatMap(l => Object.keys(l.extra)));
  [...(importTab === "paste" ? lastFieldOrder : []), ...used].forEach(k => {
    if(used.has(k) && !db.settings.fields.includes(k)) db.settings.fields.push(k);
  });
  save(); render();
  pasteArea.value = ""; $("#pasteSource").value = ""; parsed = []; $("#previewWrap").innerHTML = "";
  $$("#singleForm [name]").forEach(el => el.value = "");
  closeOverlay($("#importOverlay"));
  toast(added.length === 1 ? "1 Lead übernommen" : added.length + " Leads übernommen");
  board.scrollTo({left:0, behavior:"smooth"});
});

/* ================= E-Mail schreiben ================= */
let composeLead = null, composeTpl = null;
const usesTermin = t => /\{\{\s*(datum|uhrzeit|termin)\s*\}\}/.test(t.subject + t.body);
const usesLink = t => /\{\{\s*link\s*\}\}/.test(t.subject + t.body);
const usesVideo = t => /\{\{\s*video\s*\}\}/.test(t.subject + t.body);
// Nummer mitten im Satz (nicht nur allein in der Signaturzeile)
const usesPhone = t => /\S[^\n]*\{\{\s*absender_telefon\s*\}\}|\{\{\s*absender_telefon\s*\}\}[^\n]*\S/.test(t.subject + "\n" + t.body);
function suggestTemplate(l){
  const T = db.settings.templates;
  if(l.stage === "termin") return T.find(t => t.id === "termin") || T[0];
  if(l.attempts || l.stage === "nachhaken") return T.find(t => t.id === "nachtelefonat") || T[0];
  return T[0];
}
function openComposer(l){
  composeLead = l;
  composeTpl = suggestTemplate(l);
  $("#cTo").textContent = "E-Mail an " + displayName(l) + " · " + l.email;
  renderComposer();
  openOverlay($("#composeOverlay"));
}
function renderComposer(){
  const l = composeLead, t = composeTpl; if(!l || !t) return;
  $("#cList").innerHTML = db.settings.templates.map(x => `<button type="button" class="tpl ${x === t ? "on" : ""}" data-tpl="${esc(x.id)}">
      <b>${esc(x.name)}</b><small>${esc(fillTemplate(x.subject, l))}</small></button>`).join("");
  const inputs = [];
  if(usesTermin(t)) inputs.push(`<label class="fl"><span class="label">Datum &amp; Uhrzeit</span><input class="input" type="datetime-local" data-c="termin" value="${esc(l.termin||"")}"></label>`);
  if(usesLink(t)) inputs.push(`<label class="fl"><span class="label">Meeting-Link</span><input class="input" type="url" data-c="meetlink" value="${esc(l.meetlink||"")}" placeholder="https://meet.google.com/…" autocapitalize="off"></label>`);
  if(usesPhone(t) && !db.settings.senderPhone) inputs.push(`<label class="fl"><span class="label">Ihre Telefonnummer (gilt für alle Leads)</span><input class="input" type="tel" data-c="senderPhone" value="" placeholder="z. B. +49 171 1234567"></label>`);
  if(usesVideo(t)) inputs.push(`<label class="fl span2"><span class="label">Link zum Beispielvideo (gilt für alle Leads)</span><input class="input" type="url" data-c="video" value="${esc(db.settings.video||"")}" placeholder="z. B. YouTube-, Vimeo- oder Drive-Link" autocapitalize="off"></label>`);
  $("#cInputs").innerHTML = inputs.join("");
  renderComposePreview();
  const move = t.stage && t.stage !== l.stage && STAGE_NAME[t.stage];
  $("#cMoveWrap").classList.toggle("hidden", !move);
  if(move) $("#cMoveText").textContent = "Danach nach „" + STAGE_NAME[t.stage] + "“ verschieben";
}
function missingFor(l, t){
  const m = [];
  if(usesTermin(t) && !l.termin) m.push("Datum & Uhrzeit");
  if(usesLink(t) && !l.meetlink) m.push("Meeting-Link");
  if(usesVideo(t) && !db.settings.video) m.push("Link zum Beispielvideo");
  if(usesPhone(t) && !db.settings.senderPhone) m.push("Ihre Telefonnummer");
  return m;
}
function renderComposePreview(){
  const l = composeLead, t = composeTpl;
  $("#cPreview").innerHTML = `<span class="subj">${esc(fillTemplate(t.subject, l))}</span>${esc(fillTemplate(t.body, l))}`;
  const miss = missingFor(l, t);
  $("#cGo").disabled = false;
  $("#cGo").title = miss.length ? "Fehlt noch: " + miss.join(", ") : "";
}
$("#cList").addEventListener("click", e => {
  const b = e.target.closest("[data-tpl]"); if(!b) return;
  composeTpl = db.settings.templates.find(x => x.id === b.dataset.tpl) || composeTpl;
  $("#cMove").checked = true;
  renderComposer();
});
$("#cInputs").addEventListener("input", e => {
  const k = e.target.dataset.c; if(!k) return;
  const v = e.target.value.trim();
  if(k === "video" || k === "senderPhone") db.settings[k] = v;
  else { composeLead[k] = v; touch(composeLead); }
  save(); renderComposePreview();
});
$("#cGo").addEventListener("click", () => {
  const l = composeLead, t = composeTpl; if(!l || !t) return;
  const miss = missingFor(l, t);
  if(miss.length && !confirm("Es fehlt noch: " + miss.join(", ") + ".\n\nTrotzdem öffnen? Die Lücke steht dann leer in der Mail.")) return;
  if(t.stage && t.stage !== l.stage && $("#cMove").checked) setStage(l, t.stage);
  closeOverlay($("#composeOverlay"));
  sendMail(l, t);
});

/* ================= Einstellungen ================= */
const sSubject = $("#sSubject"), sBody = $("#sBody");
let lastFocusTpl = sBody;
function sampleLead(){
  return db.leads.find(l => l.stage === "email" && l.email) || db.leads.find(l => l.name) ||
    {anrede:"Herr", name:"Jonas Weber", firma:"Weber Wohnbau GmbH", ort:"München"};
}
let editTplId = null;
const editTpl = () => db.settings.templates.find(t => t.id === editTplId) || db.settings.templates[0];
function renderMailPreview(){
  const l = Object.assign({termin: (() => { const d = new Date(Date.now() + 3 * 864e5); d.setHours(10, 0, 0, 0); return d.toISOString(); })(),
    meetlink:"https://meet.google.com/abc-defg-hij"}, sampleLead());
  const t = editTpl();
  $("#sPreview").innerHTML = `<span class="subj">${esc(fillTemplate(t.subject, l))}</span>${esc(fillTemplate(t.body, l))}`;
}
function fillTplEditor(){
  const T = db.settings.templates, t = editTpl();
  editTplId = t.id;
  $("#sTplSel").innerHTML = T.map(x => `<option value="${esc(x.id)}" ${x === t ? "selected" : ""}>${esc(x.name)}</option>`).join("");
  $("#sTplStage").innerHTML = `<option value="">nicht verschieben</option>` + STAGES.map(st => `<option value="${st.id}" ${t.stage === st.id ? "selected" : ""}>${esc(STAGE_NAME[st.id])}</option>`).join("");
  $("#sTplName").value = t.name; sSubject.value = t.subject; sBody.value = t.body;
  $("#sTplDel").disabled = T.length <= 1;
  $("#sResetTpl").classList.toggle("hidden", !defaultTemplates().some(d => d.id === t.id));
  renderMailPreview();
}
function fillSettings(){
  const s = db.settings;
  fillTplEditor();
  $("#sSenderPhone").value = s.senderPhone || "";
  $("#sVideo").value = s.video || "";
  $$("#sMode input").forEach(r => r.checked = r.value === s.mode);
  $("#sSender").value = s.sender || "";
  $("#sAccount").value = s.account || "0";
  $("#sChips").innerHTML = PLACEHOLDERS.map(p => `<button type="button" class="chip" data-ph="${p}">{{${p}}}</button>`).join("");
  if(SERVER) $("#sDataText").textContent = "Alle Leads werden auf diesem Computer in der Datei „" + (window.RW_DATAFILE || "leads.json") + "“ gespeichert – ohne Cloud, ohne Kosten. Das Skript legt zusätzlich jeden Tag automatisch eine Sicherung an. Eine heruntergeladene Sicherung eignet sich, um die Leads auf ein anderes Gerät zu übertragen.";
  renderPhoneSection();
  $("#sVersion").textContent = SERVER ? "Version " + (window.RW_VERSION || "–") + " · lokal" : "Online-Version";
  $("#sLastBackup").textContent = s.lastBackup ? "Letzte Sicherung: " + fmtDate(s.lastBackup) : "Noch keine Sicherung heruntergeladen.";
  renderMailPreview();
}
function renderPhoneSection(){
  const sec = $("#sPhone"), body = $("#sPhoneBody");
  sec.classList.toggle("hidden", !SERVER);
  if(!SERVER) return;
  if(REMOTE){
    body.innerHTML = `<p class="lead-text">Sie sind mit dem CRM auf Ihrem Computer verbunden. Alles, was Sie hier ändern, wird direkt dort gespeichert. Tipp: Über „Teilen → Zum Home-Bildschirm“ (iPhone) bzw. „⋮ → Zum Startbildschirm hinzufügen“ (Android) haben Sie das CRM wie eine App auf dem Handy.</p>`;
    return;
  }
  if(!window.RW_PHONE_URL){
    body.innerHTML = `<p class="lead-text">Damit Sie das CRM auch auf dem Handy öffnen können, starten Sie es am Computer mit <b>„raumwerk CRM starten (Handy)“</b> statt mit der normalen Startdatei. Hier erscheint dann ein QR-Code zum Scannen.</p>
      <p class="hint">Das Handy muss im gleichen WLAN sein wie dieser Computer, und der Computer muss laufen.</p>`;
    return;
  }
  let svg = "";
  try{ const q = qrcode(0, "M"); q.addData(window.RW_PHONE_URL); q.make(); svg = q.createSvgTag({cellSize:4, margin:2, scalable:true}); }catch(_){}
  body.innerHTML = `<div class="phone-box">
      <div class="qr">${svg}</div>
      <ol class="phone-steps">
        <li>Handy mit dem <b>gleichen WLAN</b> verbinden wie diesen Computer.</li>
        <li>QR-Code mit der Handy-Kamera scannen und den Link öffnen.</li>
        <li>Für schnellen Zugriff: „Teilen → Zum Home-Bildschirm“ (iPhone) bzw. „⋮ → Zum Startbildschirm hinzufügen“ (Android).</li>
        <li>Das CRM am Computer muss dabei laufen – alle Änderungen landen direkt in Ihrer Datei.</li>
      </ol>
    </div>
    <p class="phone-link">${esc(window.RW_PHONE_URL)}</p>
    <p class="hint">Der Link enthält Ihren persönlichen Zugangsschlüssel – bitte nicht weitergeben. Neuen Schlüssel erzeugen: Datei „handy-zugang.txt“ im Ordner raumwerk-daten löschen und neu starten.</p>`;
}
$("#openSettings").addEventListener("click", () => { fillSettings(); openOverlay($("#settingsOverlay")); });
[sSubject, sBody].forEach(el => {
  el.addEventListener("focus", () => lastFocusTpl = el);
  el.addEventListener("input", () => { const t = editTpl(); t.subject = sSubject.value; t.body = sBody.value; save(); renderMailPreview(); });
});
$("#sChips").addEventListener("mousedown", e => { if(e.target.closest(".chip")) e.preventDefault(); });
$("#sChips").addEventListener("click", e => {
  const c = e.target.closest(".chip"); if(!c) return;
  const el = lastFocusTpl, ins = "{{" + c.dataset.ph + "}}";
  const a = el.selectionStart ?? el.value.length, b = el.selectionEnd ?? el.value.length;
  el.value = el.value.slice(0, a) + ins + el.value.slice(b);
  el.focus(); el.selectionStart = el.selectionEnd = a + ins.length;
  el.dispatchEvent(new Event("input"));
});
$("#sResetTpl").addEventListener("click", () => {
  const t = editTpl(), d = defaultTemplates().find(x => x.id === t.id); if(!d) return;
  if(!confirm("„" + t.name + "“ auf den ursprünglichen Text zurücksetzen?")) return;
  Object.assign(t, d); save(); fillTplEditor();
});
$("#sTplSel").addEventListener("change", e => { editTplId = e.target.value; fillTplEditor(); });
$("#sTplName").addEventListener("input", e => {
  const t = editTpl(); t.name = e.target.value.trim() || "Ohne Namen"; save();
  const o = $$("#sTplSel option").find(x => x.value === t.id); if(o) o.textContent = t.name;
});
$("#sTplStage").addEventListener("change", e => { editTpl().stage = e.target.value; save(); });
$("#sTplAdd").addEventListener("click", () => {
  const name = (prompt("Name der neuen Vorlage:") || "").trim(); if(!name) return;
  const t = {id:uid(), name, subject:"", body:"{{begruessung}},\n\n\n\nHerzliche Grüße\n{{absender}}\n\nraumwerk\nws-strategy.de", stage:""};
  db.settings.templates.push(t); editTplId = t.id; save(); fillTplEditor(); sSubject.focus();
});
$("#sTplDel").addEventListener("click", () => {
  const T = db.settings.templates; if(T.length <= 1) return;
  const t = editTpl();
  if(!confirm("Vorlage „" + t.name + "“ löschen?")) return;
  db.settings.templates = T.filter(x => x !== t); editTplId = null; save(); fillTplEditor();
});
$("#sSenderPhone").addEventListener("input", e => { db.settings.senderPhone = e.target.value.trim(); save(); renderMailPreview(); });
$("#sVideo").addEventListener("input", e => { db.settings.video = e.target.value.trim(); save(); renderMailPreview(); });
$("#sMode").addEventListener("change", e => { db.settings.mode = e.target.value; save(); });
$("#sSender").addEventListener("input", e => { db.settings.sender = e.target.value.trim(); save(); renderMailPreview(); });
$("#sAccount").addEventListener("change", e => { db.settings.account = e.target.value; save(); });

function download(name, content, type){
  const blob = new Blob([content], {type});
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob); a.download = name;
  document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(a.href), 2000);
}
$("#sExport").addEventListener("click", () => {
  db.settings.lastBackup = now(); save();
  download("raumwerk-leads-" + todayStr() + ".json", JSON.stringify(db, null, 2), "application/json");
  fillSettings();
});
$("#sCsv").addEventListener("click", () => {
  const xf = db.settings.fields || [];
  const cols = ["Phase","Anrede","Name","Firma","Telefon","E-Mail","Ort","Website","Quelle","Wiedervorlage","Anrufversuche","Angelegt","Letzte Notiz", ...xf];
  const q = v => '"' + String(v ?? "").replace(/"/g,'""') + '"';
  const rows = db.leads.map(l => [STAGE_NAME[l.stage], l.anrede, l.name, l.firma, l.telefon, l.email, l.ort, l.website, l.quelle,
    l.wiedervorlage, l.attempts||0, fmtDate(l.created,false), ((l.notes||[]).find(n=>!n.sys)||{}).text || "", ...xf.map(k => (l.extra||{})[k] || "")].map(q).join(";"));
  download("raumwerk-leads-" + todayStr() + ".csv", "﻿" + [cols.map(q).join(";"), ...rows].join("\n"), "text/csv");
});
$("#sImportFile").addEventListener("change", async e => {
  const f = e.target.files[0]; e.target.value = ""; if(!f) return;
  try{
    const d = JSON.parse(await f.text());
    if(!d || !Array.isArray(d.leads)) throw new Error("format");
    const merge = db.leads.length && confirm(
      "Sicherung mit " + d.leads.length + " Leads gefunden.\n\nOK = mit den vorhandenen Leads zusammenführen\nAbbrechen = vorhandene Leads ersetzen");
    if(merge){
      const ids = new Set(db.leads.map(l => l.id));
      d.leads.forEach(l => { if(!ids.has(l.id)) db.leads.push(l); });
      ((d.settings || {}).fields || []).forEach(k => { if(!db.settings.fields.includes(k)) db.settings.fields.push(k); });
      db = normalize(db);
    }else{
      if(db.leads.length && !confirm("Alle " + db.leads.length + " vorhandenen Leads werden ersetzt. Fortfahren?")) return;
      db.leads = d.leads;
      db.settings = Object.assign(defaultDb().settings, d.settings || {});
      db = normalize(db);
    }
    save(); render(); fillSettings();
    toast("Sicherung eingespielt");
  }catch(err){ toast("Diese Datei ist keine gültige raumwerk-Sicherung."); }
});
$("#sWipe").addEventListener("click", () => {
  if(!db.leads.length) return;
  if(!confirm("Wirklich alle " + db.leads.length + " Leads löschen? Das lässt sich nicht rückgängig machen.")) return;
  if(!confirm("Letzte Bestätigung: alle Leads löschen?")) return;
  db.leads.forEach(l => forget(l.id));
  db.leads = []; save(); render(); toast("Alle Leads gelöscht");
});

/* ================= Hinweis ================= */
let toastTimer = null;
function toast(html, actionLabel, action){
  const t = $("#toast"), b = $("#toastAction");
  $("#toastText").innerHTML = html;
  if(actionLabel){
    b.textContent = actionLabel; b.classList.remove("hidden"); t.classList.add("has-action");
    b.onclick = () => { action(); t.classList.remove("show"); };
  }else{ b.classList.add("hidden"); t.classList.remove("has-action"); }
  t.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => t.classList.remove("show"), actionLabel ? 6000 : 2600);
}

if(SERVER){
  fetchData().catch(() => rwShowError(REMOTE
    ? "Der Computer ist nicht erreichbar. Läuft dort „raumwerk CRM starten (Handy)“, und ist das Handy im gleichen WLAN?"
    : "Die Daten konnten nicht geladen werden. Läuft das Python-Fenster noch?"));
  // Beim Zurückkehren in den Tab Änderungen aus anderen Fenstern übernehmen
  document.addEventListener("visibilitychange", () => {
    if(document.visibilityState === "visible" && loaded && !dirty && !pushing && !drag && !$(".overlay.open"))
      api({cache:"no-store"}).then(r => r.json()).then(j => {
        if(j.rev !== rev && !dirty){ db = normalize(j.data); rev = j.rev; render(); }
      }).catch(() => {});
    if(document.visibilityState === "hidden" && dirty) push(true);
  });
  window.addEventListener("pagehide", () => { if(dirty) push(true); });
}else{
  window.addEventListener("storage", e => { if(e.key === KEY){ db = load(); render(); } });
  render();
}
})();
</script>
</body>
</html>
'''


# ---------------------------------------------------------------- Speicher

class Speicher:
    """Liest und schreibt leads.json atomar und legt tägliche Sicherungen an."""

    def __init__(self, ordner):
        self.ordner = os.path.abspath(ordner)
        self.datei = os.path.join(self.ordner, "leads.json")
        self.sicherungen = os.path.join(self.ordner, "sicherungen")
        self.lock = threading.Lock()
        os.makedirs(self.sicherungen, exist_ok=True)
        self.rev = 0
        self.daten = None
        self._laden()

    def _laden(self):
        if not os.path.exists(self.datei):
            self.daten = None
            return
        try:
            with open(self.datei, "r", encoding="utf-8") as f:
                inhalt = json.load(f)
            self.rev = int(inhalt.get("rev", 0))
            self.daten = inhalt.get("data")
        except (OSError, ValueError) as fehler:
            # Defekte Datei nicht überschreiben, sondern beiseitelegen
            kaputt = self.datei + ".defekt-" + datetime.now().strftime("%Y%m%d-%H%M%S")
            shutil.copy2(self.datei, kaputt)
            print("  ! leads.json war nicht lesbar ({}).".format(fehler))
            print("    Kopie gesichert unter: {}".format(kaputt))
            print("    Die letzte Tagessicherung liegt in: {}".format(self.sicherungen))
            self.daten = None

    def lesen(self):
        with self.lock:
            return {"rev": self.rev, "data": self.daten}

    def schreiben(self, daten, rev, erzwingen=False):
        with self.lock:
            if not erzwingen and rev != self.rev:
                return None  # in einem anderen Fenster geändert
            self.rev += 1
            self.daten = daten
            inhalt = json.dumps({"rev": self.rev, "gespeichert": datetime.now().isoformat(timespec="seconds"),
                                 "data": daten}, ensure_ascii=False, indent=1)
            fd, tmp = tempfile.mkstemp(prefix=".leads-", suffix=".tmp", dir=self.ordner)
            try:
                with os.fdopen(fd, "w", encoding="utf-8") as f:
                    f.write(inhalt)
                    f.flush()
                    os.fsync(f.fileno())
                os.replace(tmp, self.datei)
            except BaseException:
                try:
                    os.remove(tmp)
                except OSError:
                    pass
                raise
            self._tagessicherung()
            return self.rev

    def _tagessicherung(self):
        ziel = os.path.join(self.sicherungen, "leads-{}.json".format(date.today().isoformat()))
        try:
            shutil.copy2(self.datei, ziel)  # überschreibt die Sicherung von heute: Stand am Tagesende
            alte = sorted(n for n in os.listdir(self.sicherungen) if n.startswith("leads-") and n.endswith(".json"))
            for name in alte[:-MAX_SICHERUNGEN]:
                os.remove(os.path.join(self.sicherungen, name))
        except OSError as fehler:
            print("  ! Sicherung fehlgeschlagen: {}".format(fehler))


GESPERRT = """<!DOCTYPE html><html lang="de"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1"><title>raumwerk · Leads</title></head>
<body style="margin:0;background:#F4F1EA;color:#23332A;font-family:Georgia,serif;display:flex;min-height:100vh;align-items:center;justify-content:center;padding:24px;text-align:center">
<div style="max-width:420px"><p style="font-size:30px;margin:0 0 12px">raum<i style="color:#6E7A5E">werk</i></p>
<p style="font-family:system-ui,sans-serif;font-size:15px;line-height:1.6;color:#6B6F68">Für den Zugriff vom Handy bitte den QR-Code bzw. Link aus den
Einstellungen des CRM am Computer verwenden.</p></div></body></html>""".encode("utf-8")


# ---------------------------------------------------------------- Handy-Zugang

def zugangsschluessel(ordner):
    """Geheimer Schlüssel für Geräte im WLAN. Bleibt gleich, damit Lesezeichen weiter funktionieren.
    Neuen Schlüssel erzwingen: Datei handy-zugang.txt löschen."""
    datei = os.path.join(ordner, "handy-zugang.txt")
    try:
        with open(datei, "r", encoding="utf-8") as f:
            k = f.read().strip()
        if re.fullmatch(r"[A-Za-z0-9_-]{20,}", k):
            return k
    except OSError:
        pass
    k = secrets.token_urlsafe(18)
    with open(datei, "w", encoding="utf-8") as f:
        f.write(k + "\n")
    try:
        os.chmod(datei, 0o600)
    except OSError:
        pass
    return k


def lan_ip():
    """IP-Adresse dieses Computers im WLAN/LAN (es wird nichts gesendet)."""
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
            s.connect(("10.255.255.255", 1))
            ip = s.getsockname()[0]
            if not ip.startswith("127."):
                return ip
    except OSError:
        pass
    try:
        ip = socket.gethostbyname(socket.gethostname())
        if not ip.startswith("127."):
            return ip
    except OSError:
        pass
    return None


# ---------------------------------------------------------------- Server

def baue_handler(speicher, port, handy=None):
    """handy: None (nur dieser Computer) oder {"schluessel": ..., "url": ...}"""
    erlaubte_hosts = {"127.0.0.1:{}".format(port), "localhost:{}".format(port)}
    ip_host = re.compile(r"^\d{1,3}(\.\d{1,3}){3}:%d$" % port)

    def seite_fuer(lokal):
        info = {"RW_SERVER": True, "RW_DATAFILE": speicher.datei, "RW_VERSION": VERSION,
                "RW_HANDY": bool(handy), "RW_LOCAL": lokal}
        if handy and lokal:
            info["RW_PHONE_URL"] = handy["url"]  # nur der Computer selbst bekommt den Link angezeigt
        js = "".join("window.{}={};".format(k, json.dumps(v)) for k, v in info.items())
        return HTML.replace("<!--RW_SERVER-->", "<script>" + js.replace("</", "<\\/") + "</script>").encode("utf-8")

    seite_lokal, seite_handy = seite_fuer(True), seite_fuer(False)

    class Handler(BaseHTTPRequestHandler):
        server_version = "raumwerk"
        sys_version = ""

        def log_message(self, *args):
            pass  # ruhige Konsole

        def _lokal(self):
            return self.client_address[0] in ("127.0.0.1", "::1", "::ffff:127.0.0.1")

        def _host_ok(self):
            # Schutz gegen fremde Webseiten, die per DNS-Trick auf localhost zugreifen:
            # nur localhost bzw. (im Handy-Modus) eine nackte IP-Adresse als Host.
            host = self.headers.get("Host", "")
            return host in erlaubte_hosts or bool(handy and ip_host.match(host))

        def _schluessel_aus_anfrage(self):
            q = urllib.parse.parse_qs(urllib.parse.urlsplit(self.path).query)
            kandidaten = q.get("k", []) + [self.headers.get("X-Raumwerk-Key", "")]
            for teil in self.headers.get("Cookie", "").split(";"):
                name, _, wert = teil.strip().partition("=")
                if name == "rw_k":
                    kandidaten.append(wert)
            return kandidaten

        def _zugang_ok(self):
            if self._lokal():
                return True
            if not handy:
                return False
            return any(k and hmac.compare_digest(k, handy["schluessel"]) for k in self._schluessel_aus_anfrage())

        def _senden(self, status, body, typ="application/json; charset=utf-8", cookie=None):
            if isinstance(body, (dict, list)):
                body = json.dumps(body, ensure_ascii=False).encode("utf-8")
            self.send_response(status)
            if cookie:
                self.send_header("Set-Cookie", "rw_k={}; Path=/; Max-Age=31536000; HttpOnly; SameSite=Strict".format(cookie))
            self.send_header("Content-Type", typ)
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", "no-store")
            self.send_header("X-Content-Type-Options", "nosniff")
            self.send_header("Referrer-Policy", "no-referrer")
            self.end_headers()
            self.wfile.write(body)

        def do_GET(self):
            if not self._host_ok():
                return self._senden(403, {"fehler": "nicht erlaubt"})
            pfad = self.path.split("?", 1)[0]
            if pfad == "/api/ping" and self._lokal():
                return self._senden(200, {"app": APP_NAME, "version": VERSION, "daten": speicher.datei,
                                          "handy": bool(handy)})
            if not self._zugang_ok():
                if pfad in ("/", "/index.html"):
                    return self._senden(403, GESPERRT, "text/html; charset=utf-8")
                return self._senden(403, {"fehler": "Zugangsschlüssel fehlt"})
            if pfad in ("/", "/index.html"):
                if self._lokal():
                    return self._senden(200, seite_lokal, "text/html; charset=utf-8")
                return self._senden(200, seite_handy, "text/html; charset=utf-8", cookie=handy["schluessel"])
            if pfad == "/api/daten":
                return self._senden(200, speicher.lesen())
            if pfad == "/favicon.ico":
                return self._senden(204, b"", "image/x-icon")
            return self._senden(404, {"fehler": "nicht gefunden"})

        def do_POST(self):
            # Eigener Header erzwingt eine CORS-Vorabprüfung, die wir nie erlauben:
            # fremde Webseiten können so nichts in die Datei schreiben.
            if not self._host_ok() or self.headers.get("X-Raumwerk") != "1" or not self._zugang_ok():
                return self._senden(403, {"fehler": "nicht erlaubt"})
            if self.path.split("?", 1)[0] == "/api/beenden":
                if not self._lokal():
                    return self._senden(403, {"fehler": "nicht erlaubt"})
                # Eine neuere Version übernimmt: diesen Server sauber beenden
                self._senden(200, {"ok": True})
                threading.Thread(target=self.server.shutdown, daemon=True).start()
                return
            if self.path.split("?", 1)[0] != "/api/daten":
                return self._senden(404, {"fehler": "nicht gefunden"})
            try:
                laenge = int(self.headers.get("Content-Length", "0"))
            except ValueError:
                laenge = 0
            if laenge <= 0 or laenge > MAX_GROESSE:
                return self._senden(413, {"fehler": "ungültige Größe"})
            try:
                anfrage = json.loads(self.rfile.read(laenge).decode("utf-8"))
                daten = anfrage["data"]
                if not isinstance(daten, dict) or not isinstance(daten.get("leads"), list):
                    raise ValueError("leads fehlt")
                rev = int(anfrage.get("rev", 0))
            except (ValueError, KeyError, TypeError, UnicodeDecodeError):
                return self._senden(400, {"fehler": "ungültige Daten"})
            try:
                neu = speicher.schreiben(daten, rev, bool(anfrage.get("force")))
            except OSError as fehler:
                print("  ! Speichern fehlgeschlagen: {}".format(fehler))
                return self._senden(500, {"fehler": "Speichern fehlgeschlagen"})
            if neu is None:
                return self._senden(409, {"fehler": "veraltet", "rev": speicher.rev})
            return self._senden(200, {"rev": neu})

    return Handler


def laeuft_schon(port):
    """Antwort des bereits laufenden CRM (dict) oder None."""
    try:
        with urllib.request.urlopen("http://127.0.0.1:{}/api/ping".format(port), timeout=1) as r:
            info = json.loads(r.read().decode("utf-8"))
            return info if info.get("app") == APP_NAME else None
    except Exception:
        return None


def windows_prozess_beenden(port):
    """Ältere Versionen kennen /api/beenden nicht: unter Windows den Prozess am Port beenden.
    Wird nur aufgerufen, nachdem /api/ping bestätigt hat, dass dort das raumwerk CRM läuft."""
    import subprocess
    try:
        ausgabe = subprocess.run(["netstat", "-ano", "-p", "TCP"], capture_output=True, text=True,
                                 errors="replace", timeout=10).stdout
    except Exception:
        return False
    pids = set()
    for zeile in ausgabe.splitlines():
        teile = zeile.split()
        # TCP  127.0.0.1:8765  0.0.0.0:0  ABHÖREN/LISTENING  1234
        if len(teile) >= 5 and teile[0].upper() == "TCP" and teile[1] == "127.0.0.1:{}".format(port) \
                and teile[2] in ("0.0.0.0:0", "*:*") and teile[-1].isdigit():
            pids.add(teile[-1])
    pids.discard(str(os.getpid()))
    for pid in pids:
        subprocess.run(["taskkill", "/PID", pid, "/F"], capture_output=True, timeout=10)
    for _ in range(30):
        time.sleep(0.2)
        if not laeuft_schon(port):
            return True
    return False


def alten_beenden(port):
    try:
        req = urllib.request.Request("http://127.0.0.1:{}/api/beenden".format(port), data=b"{}", method="POST",
                                     headers={"X-Raumwerk": "1", "Content-Type": "application/json"})
        urllib.request.urlopen(req, timeout=2).read()
    except Exception:
        return False
    for _ in range(30):
        time.sleep(0.2)
        if not laeuft_schon(port):
            return True
    return False


def port_frei(port, adresse="127.0.0.1"):
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        if os.name != "nt":
            s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)  # wie der Server selbst
        try:
            s.bind((adresse, port))
            return True
        except OSError:
            return False


def main():
    if sys.version_info < (3, 7):
        print("Bitte Python 3.7 oder neuer verwenden.")
        sys.exit(1)

    for strom in (sys.stdout, sys.stderr):
        try:
            strom.reconfigure(errors="replace")  # Umlaute auch in alten Windows-Konsolen
        except Exception:
            pass

    hier = os.path.dirname(os.path.abspath(__file__))
    parser = argparse.ArgumentParser(description="raumwerk CRM lokal starten")
    parser.add_argument("--port", type=int, default=STANDARD_PORT)
    parser.add_argument("--daten", default=os.path.join(hier, "raumwerk-daten"))
    parser.add_argument("--kein-browser", action="store_true")
    parser.add_argument("--handy", action="store_true", help="auch im eigenen WLAN erreichbar (mit Zugangsschlüssel)")
    args = parser.parse_args()

    port = args.port
    laufend = laeuft_schon(port)
    if laufend and laufend.get("version") == VERSION and bool(laufend.get("handy")) == args.handy:
        url = "http://127.0.0.1:{}/".format(port)
        print("{} läuft bereits – öffne {}".format(APP_NAME, url))
        if not args.kein_browser:
            webbrowser.open(url)
        return
    if laufend:
        # Eine andere (ältere) Version oder ein anderer Modus läuft noch und würde sonst weiter angezeigt.
        beendet = alten_beenden(port) if laufend.get("version") else False
        if not beendet and os.name == "nt":
            beendet = windows_prozess_beenden(port)
        if not beendet:
            print()
            print("  ACHTUNG: Es läuft noch eine ältere Version des raumwerk CRM.")
            print("  Bitte alle schwarzen raumwerk-Fenster schließen")
            print("  (oder den Computer neu starten) und dann erneut starten.")
            print()
            sys.exit(1)
        print("  Laufendes raumwerk CRM beendet – starte neu.")
    # Falls der Port von etwas anderem belegt ist, den nächsten freien nehmen.
    # Hinweis: Die Leads liegen in der Datei, nicht im Browser – der Port ist egal.
    adresse = "0.0.0.0" if args.handy else "127.0.0.1"
    while not port_frei(port, adresse):
        port += 1
        if port > args.port + 50:
            print("Kein freier Port gefunden.")
            sys.exit(1)

    speicher = Speicher(args.daten)
    handy = None
    if args.handy:
        ip = lan_ip()
        if not ip:
            print("  ! Keine WLAN-Verbindung gefunden – Handy-Zugang nicht möglich. Starte nur für diesen Computer.")
            adresse = "127.0.0.1"
        else:
            schluessel = zugangsschluessel(speicher.ordner)
            handy = {"schluessel": schluessel, "url": "http://{}:{}/?k={}".format(ip, port, schluessel)}
    server = ThreadingHTTPServer((adresse, port), baue_handler(speicher, port, handy))
    url = "http://127.0.0.1:{}/".format(port)

    anzahl = len((speicher.daten or {}).get("leads", []))
    print()
    print("  raumwerk CRM läuft.  (Version {})".format(VERSION))
    print("  Im Browser:  {}".format(url))
    print("  Daten:       {}  ({} Leads)".format(speicher.datei, anzahl))
    if handy:
        print()
        print("  Handy (gleiches WLAN): QR-Code im CRM unter Einstellungen → Handy")
        print("  oder diesen Link öffnen:")
        print("    {}".format(handy["url"]))
        print("  Den Link nicht weitergeben – er ist Ihr Zugangsschlüssel.")
        if os.name == "nt":
            print("  Fragt Windows nach dem Netzwerkzugriff: „Private Netzwerke“ erlauben.")
    print()
    print("  Dieses Fenster geöffnet lassen, solange Sie arbeiten.")
    print("  Beenden mit Strg + C oder Fenster schließen.")
    print()

    if not args.kein_browser:
        threading.Timer(0.6, lambda: webbrowser.open(url)).start()
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()
        print("\n  raumwerk CRM beendet. Alle Daten sind gespeichert.")


if __name__ == "__main__":
    main()
